import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Country, ExchangeRate } from '../types';

interface CountryContextType {
  user: User | null;
  countries: Country[];
  exchangeRates: ExchangeRate[];
  selectedCountry: Country | null;
  loading: boolean;
  error: string | null;
  formatPrice: (priceInTZS: number) => string;
  updateUserCountry: (countryId: number) => Promise<void>;
  refreshUser: () => Promise<void>;
  login: (identifier: string, password: string) => Promise<boolean>;
  signup: (data: any) => Promise<boolean>;
  logout: () => void;
}

const CountryContext = createContext<CountryContextType | undefined>(undefined);

export function CountryProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [countries, setCountries] = useState<Country[]>([]);
  const [exchangeRates, setExchangeRates] = useState<ExchangeRate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      // 1. Fetch User Profile first (Lightweight check)
      const userRes = await fetch('/api/user');
      let userData = null;
      
      if (userRes.ok) {
        userData = await userRes.json();
        setUser(userData);
      } else if (userRes.status === 404 || userRes.status === 401) {
        setUser(null);
      } else {
        console.warn(`User fetch returned status: ${userRes.status}`);
      }

      // 2. Only fetch country modules if we have a user or if we are at login/signup
      // For a fail-safe startup, we fetch these in parallel but handle failures individually
      const [countriesRes, ratesRes] = await Promise.all([
        fetch('/api/countries').catch(e => { console.error('Countries fetch failed', e); return null; }),
        fetch('/api/exchange-rates').catch(e => { console.error('Rates fetch failed', e); return null; })
      ]);

      if (countriesRes?.ok) {
        const countriesData = await countriesRes.json();
        setCountries(countriesData);
      }
      
      if (ratesRes?.ok) {
        const ratesData = await ratesRes.json();
        setExchangeRates(ratesData);
      }

    } catch (err) {
      console.error('Critical startup error:', err);
      setError('Failed to initialize application');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Safe null checks for selected country
  const selectedCountry = user && countries.length > 0 
    ? (countries.find(c => c.id === user.country_id) || countries[0]) 
    : (countries[0] || null);

  const formatPrice = (priceInTZS: number) => {
    if (!selectedCountry) return `${priceInTZS.toLocaleString()} TZS`;

    const rate = exchangeRates.find(r => r.from_currency === 'TZS' && r.to_currency === selectedCountry.currency_code);
    const convertedPrice = rate ? priceInTZS * rate.rate : priceInTZS;

    if (selectedCountry.code === 'NG') {
      return `${selectedCountry.currency_symbol}${Math.round(convertedPrice).toLocaleString()}`;
    }

    return `${Math.round(convertedPrice).toLocaleString()} ${selectedCountry.currency_code}`;
  };

  const updateUserCountry = async (countryId: number) => {
    if (!user) return;
    try {
      const res = await fetch('/api/user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: user.id, country_id: countryId, full_name: user.full_name, email: user.email })
      });
      if (res.ok) {
        const updatedUser = await res.json();
        setUser(updatedUser);
      }
    } catch (error) {
      console.error('Error updating country:', error);
    }
  };

  const refreshUser = async () => {
    const res = await fetch('/api/user');
    if (res.ok) setUser(await res.json());
  };

  const login = async (identifier: string, password: string) => {
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, password })
      });
      if (res.ok) {
        const userData = await res.json();
        setUser(userData);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const signup = async (data: any) => {
    try {
      const res = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) {
        const userData = await res.json();
        setUser(userData);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Signup error:', error);
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    // In a real app, clear session/token
  };

  return (
    <CountryContext.Provider value={{ 
      user, 
      countries, 
      exchangeRates, 
      selectedCountry, 
      loading, 
      error,
      formatPrice, 
      updateUserCountry,
      refreshUser,
      login,
      signup,
      logout
    }}>
      {children}
    </CountryContext.Provider>
  );
}

export function useCountry() {
  const context = useContext(CountryContext);
  if (context === undefined) {
    throw new Error('useCountry must be used within a CountryProvider');
  }
  return context;
}
