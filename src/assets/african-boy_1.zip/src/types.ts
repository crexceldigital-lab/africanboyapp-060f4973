export interface Product {
  id: number;
  name: string;
  price: number;
  category: string;
  image_url: string;
  description: string;
  stock_quantity: number;
}

export interface AppEvent {
  id: number;
  title: string;
  date: string;
  location: string;
  price: number;
  image_url: string;
}

export interface ContentItem {
  id: number;
  title: string;
  type: 'video' | 'news';
  url: string;
  is_vip: boolean;
  thumbnail_url: string;
}

export interface Country {
  id: number;
  name: string;
  code: string;
  flag_emoji: string;
  currency_code: string;
  currency_symbol: string;
  is_active: boolean;
}

export interface ExchangeRate {
  id: number;
  from_currency: string;
  to_currency: string;
  rate: number;
}

export interface User {
  id: number;
  email: string;
  full_name: string;
  role: string;
  vip_tier: string;
  country_id: number;
  country_name?: string;
  country_code?: string;
  currency_code?: string;
  currency_symbol?: string;
  created_at: string;
}

export interface Purchase {
  id: number;
  user_id: number;
  product_name: string;
  amount: number;
  currency_code: string;
  date: string;
}

export interface GalleryItem {
  id: number;
  image_url: string;
  title?: string;
  created_at: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export type NavTab = 'home' | 'video' | 'shop' | 'events' | 'vip' | 'profile' | 'admin';
