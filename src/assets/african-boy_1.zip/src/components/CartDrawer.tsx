import { motion, AnimatePresence } from 'motion/react';
import { X, Minus, Plus, Trash2, ShoppingBag, CreditCard, Smartphone, CheckCircle2, ArrowLeft, Loader2, Landmark, Wallet } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useState } from 'react';
import { useCountry } from '../context/CountryContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

type CheckoutStep = 'cart' | 'payment' | 'processing' | 'success';

const PAYMENT_METHODS_TZ = [
  { id: 'vodacom', name: 'VODACOM M-PESA', icon: Smartphone, color: 'text-red-600' },
  { id: 'yas', name: 'TIGO PESA / YAS', icon: Smartphone, color: 'text-blue-600' },
  { id: 'airtel', name: 'AIRTEL MONEY', icon: Smartphone, color: 'text-red-500' },
  { id: 'halotel', name: 'HALOPESA', icon: Smartphone, color: 'text-orange-500' },
  { id: 'bank_tz', name: 'LOCAL BANK TRANSFER', icon: Landmark, color: 'text-brand-yellow' },
];

const PAYMENT_METHODS_NG = [
  { id: 'nibss', name: 'BANK TRANSFER (NIBSS)', icon: Landmark, color: 'text-emerald-600' },
  { id: 'opay', name: 'OPAY', icon: Wallet, color: 'text-emerald-500' },
  { id: 'palmpay', name: 'PALMPAY', icon: Wallet, color: 'text-purple-500' },
  { id: 'kuda', name: 'KUDA BANK', icon: Smartphone, color: 'text-indigo-500' },
  { id: 'moniepoint', name: 'MONIEPOINT', icon: Landmark, color: 'text-blue-500' },
  { id: 'ussd', name: 'USSD BANKING', icon: Smartphone, color: 'text-gray-400' },
];

export default function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const { cart, removeFromCart, updateQuantity, cartTotal, cartCount, clearCart } = useCart();
  const { formatPrice, selectedCountry, user } = useCountry();
  const [step, setStep] = useState<CheckoutStep>('cart');
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null);
  const [phoneNumber, setPhoneNumber] = useState('');

  const paymentMethods = selectedCountry?.code === 'NG' ? PAYMENT_METHODS_NG : PAYMENT_METHODS_TZ;

  const handleCheckout = async () => {
    setStep('processing');
    
    // Simulate payment delay
    await new Promise(resolve => setTimeout(resolve, 2500));

    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user?.id || 1,
          items: cart,
          currency_code: selectedCountry?.currency_code || 'TZS'
        })
      });

      if (res.ok) {
        setStep('success');
        clearCart();
      } else {
        setStep('payment');
        alert('Checkout failed. Please try again.');
      }
    } catch (error) {
      setStep('payment');
      console.error(error);
    }
  };

  const resetAndClose = () => {
    onClose();
    setTimeout(() => {
      setStep('cart');
      setSelectedMethod(null);
      setPhoneNumber('');
    }, 300);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={resetAndClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-zinc-950 z-[70] shadow-2xl flex flex-col border-l border-white/5"
          >
            {/* Header */}
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {step === 'payment' ? (
                  <button onClick={() => setStep('cart')} className="p-1 hover:text-brand-yellow transition-colors">
                    <ArrowLeft size={20} />
                  </button>
                ) : (
                  <ShoppingBag className="text-brand-yellow" size={24} />
                )}
                <h2 className="text-xl font-black italic tracking-tight uppercase">
                  {step === 'cart' ? 'Your ' : step === 'payment' ? 'Payment ' : step === 'success' ? 'Order ' : 'Processing '}
                  <span className="text-brand-yellow">
                    {step === 'cart' ? 'Cart' : step === 'payment' ? 'Method' : step === 'success' ? 'Success' : '...'}
                  </span>
                </h2>
              </div>
              <button
                onClick={resetAndClose}
                className="p-2 hover:bg-white/5 rounded-full transition-colors text-gray-400 hover:text-white"
              >
                <X size={24} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 no-scrollbar">
              <AnimatePresence mode="wait">
                {step === 'cart' && (
                  <motion.div
                    key="cart-view"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="space-y-6"
                  >
                    {cart.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-20">
                        <div className="w-20 h-20 bg-zinc-900 rounded-full flex items-center justify-center text-gray-600">
                          <ShoppingBag size={40} />
                        </div>
                        <div>
                          <p className="text-white font-bold">Your cart is empty</p>
                          <p className="text-gray-500 text-sm mt-1">Start shopping to add items to your cart.</p>
                        </div>
                        <button onClick={resetAndClose} className="btn-primary text-xs px-8">BROWSE SHOP</button>
                      </div>
                    ) : (
                      cart.map((item) => (
                        <motion.div layout key={item.id} className="flex gap-4 group">
                          <div className="w-20 h-24 rounded-xl overflow-hidden bg-zinc-900 flex-shrink-0 border border-white/5 relative">
                            <img src={item.image_url || null} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            {item.category === 'Combo' && (
                              <div className="absolute top-1 left-1 px-1.5 py-0.5 bg-brand-yellow text-black text-[7px] font-black uppercase rounded-sm shadow-lg">
                                Combo
                              </div>
                            )}
                          </div>
                          <div className="flex-1 flex flex-col justify-between py-1">
                            <div>
                              <div className="flex justify-between items-start">
                                <h3 className="font-bold text-sm text-white/90 leading-tight">{item.name}</h3>
                                <button onClick={() => removeFromCart(item.id)} className="text-gray-600 hover:text-red-500 transition-colors">
                                  <Trash2 size={16} />
                                </button>
                              </div>
                              <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mt-1">
                                {item.category === 'Combo' ? (
                                  <span className="text-brand-yellow">Exclusive Bundle</span>
                                ) : (
                                  item.category
                                )}
                              </p>
                              {item.category === 'Combo' && (
                                <p className="text-[9px] text-zinc-500 italic mt-1 leading-tight">
                                  {item.description}
                                </p>
                              )}
                            </div>
                            <div className="flex justify-between items-end">
                              <div className="flex items-center bg-zinc-900 rounded-lg border border-white/5 p-1">
                                <button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:text-brand-yellow transition-colors"><Minus size={14} /></button>
                                <span className="w-8 text-center text-xs font-bold">{item.quantity}</span>
                                <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:text-brand-yellow transition-colors"><Plus size={14} /></button>
                              </div>
                              <div className="text-right">
                                <p className="text-brand-yellow font-black text-sm">{formatPrice(item.price * item.quantity)}</p>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))
                    )}
                  </motion.div>
                )}

                {step === 'payment' && (
                  <motion.div
                    key="payment-view"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="space-y-3">
                      <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">Select Payment Method</p>
                      {paymentMethods.map((method) => {
                        const Icon = method.icon;
                        const isSelected = selectedMethod === method.id;
                        return (
                          <button
                            key={method.id}
                            onClick={() => setSelectedMethod(method.id)}
                            className={`w-full p-4 rounded-2xl border flex items-center justify-between transition-all ${
                              isSelected ? 'bg-brand-yellow/10 border-brand-yellow' : 'bg-zinc-900 border-white/5 hover:border-white/20'
                            }`}
                          >
                            <div className="flex items-center gap-4">
                              <div className={`p-2 rounded-xl bg-black/40 ${method.color}`}>
                                <Icon size={20} />
                              </div>
                              <span className={`text-sm font-black tracking-tight ${isSelected ? 'text-white' : 'text-gray-400'}`}>
                                {method.name}
                              </span>
                            </div>
                            {isSelected && <div className="w-2 h-2 rounded-full bg-brand-yellow shadow-[0_0_10px_rgba(242,183,5,0.5)]" />}
                          </button>
                        );
                      })}
                    </div>

                    {selectedMethod && selectedMethod !== 'card' && (
                      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Phone Number</label>
                        <input
                          type="tel"
                          placeholder="e.g. 07XXXXXXXX"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          className="w-full bg-zinc-900 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-yellow transition-all"
                        />
                      </motion.div>
                    )}
                  </motion.div>
                )}

                {step === 'processing' && (
                  <motion.div
                    key="processing-view"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="h-full flex flex-col items-center justify-center text-center space-y-6 py-20"
                  >
                    <div className="relative">
                      <Loader2 size={64} className="text-brand-yellow animate-spin" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Smartphone size={24} className="text-brand-yellow/50" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-black italic tracking-tight">WAITING FOR PAYMENT</h3>
                      <p className="text-gray-500 text-sm mt-2">Please check your phone for the M-Pesa/Tigo Pesa prompt to complete the transaction.</p>
                    </div>
                  </motion.div>
                )}

                {step === 'success' && (
                  <motion.div
                    key="success-view"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="h-full flex flex-col items-center justify-center text-center space-y-6 py-20"
                  >
                    <div className="w-24 h-24 bg-emerald-500/10 rounded-full flex items-center justify-center text-emerald-500 border border-emerald-500/20">
                      <CheckCircle2 size={48} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-black italic tracking-tight uppercase">PAYMENT SUCCESSFUL</h3>
                      <p className="text-gray-500 text-sm mt-2">Thank you for supporting African Boy! Your order is being processed.</p>
                    </div>
                    <button onClick={resetAndClose} className="btn-primary px-12">DONE</button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Footer */}
            {cart.length > 0 && step !== 'success' && step !== 'processing' && (
              <div className="p-6 border-t border-white/5 bg-zinc-950 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-500 font-bold text-xs uppercase tracking-widest">Total Amount</span>
                  <span className="text-xl font-black text-white">{formatPrice(cartTotal)}</span>
                </div>
                {step === 'cart' ? (
                  <button
                    onClick={() => setStep('payment')}
                    className="w-full py-4 bg-brand-yellow text-black font-black tracking-widest text-sm rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-lg shadow-brand-yellow/10"
                  >
                    PROCEED TO CHECKOUT
                  </button>
                ) : (
                  <button
                    disabled={!selectedMethod || (selectedMethod !== 'card' && !phoneNumber)}
                    onClick={handleCheckout}
                    className="w-full py-4 bg-brand-yellow text-black font-black tracking-widest text-sm rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-lg shadow-brand-yellow/10 disabled:opacity-50 disabled:hover:scale-100"
                  >
                    PAY NOW
                  </button>
                )}
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
