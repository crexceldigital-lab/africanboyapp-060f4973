import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Upload, Check, Sparkles, ShoppingBag, Download, Share2, User, ChevronRight, Loader2 } from 'lucide-react';
import { Product } from '../types';
import { GoogleGenAI } from "@google/genai";

interface FitMeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Step = 'upload' | 'detecting' | 'select' | 'generating' | 'result';

export default function FitMeModal({ isOpen, onClose }: FitMeModalProps) {
  const [step, setStep] = useState<Step>('upload');
  const [userPhoto, setUserPhoto] = useState<string | null>(null);
  const [selectedItems, setSelectedItems] = useState<Product[]>([]);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoadingProducts, setIsLoadingProducts] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const detectionSteps = [
    'Scanning body silhouette...',
    'Identifying pose coordinates...',
    'Analyzing skin tone palette...',
    'Mapping fabric anchor points...',
    'Finalizing body metrics...'
  ];

  const generationSteps = [
    'Initializing neural engine...',
    'Stitching collection items...',
    'Matching lighting & shadows...',
    'Refining fabric textures...',
    'Applying style enhancements...',
    'Finalizing digital look...'
  ];

  useEffect(() => {
    if (isOpen && products.length === 0) {
      fetchProducts();
    }
  }, [isOpen]);

  const fetchProducts = async () => {
    setIsLoadingProducts(true);
    try {
      const res = await fetch('/api/products');
      const data = await res.json();
      setProducts(data);
    } catch (error) {
      console.error('Failed to fetch products:', error);
    } finally {
      setIsLoadingProducts(false);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUserPhoto(event.target?.result as string);
        setStep('detecting');
        setProgress(0);
        
        // Simulate progress for detection
        let currentProgress = 0;
        const interval = setInterval(() => {
          currentProgress += 5;
          setProgress(currentProgress);
          const stepIndex = Math.min(Math.floor((currentProgress / 100) * detectionSteps.length), detectionSteps.length - 1);
          setStatusMessage(detectionSteps[stepIndex]);
          
          if (currentProgress >= 100) {
            clearInterval(interval);
            setTimeout(() => setStep('select'), 500);
          }
        }, 100);
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleItem = (product: Product) => {
    setSelectedItems(prev => {
      if (prev.find(p => p.id === product.id)) {
        return prev.filter(p => p.id !== product.id);
      }
      return [...prev, product];
    });
  };

  const handleGenerate = async () => {
    if (!userPhoto || selectedItems.length === 0) return;
    
    setStep('generating');
    setProgress(0);
    
    // Simulate progress for generation (Gemini takes some time)
    let currentProgress = 0;
    const interval = setInterval(() => {
      if (currentProgress < 90) {
        currentProgress += Math.random() * 5;
        setProgress(Math.min(currentProgress, 90));
        const stepIndex = Math.min(Math.floor((currentProgress / 100) * generationSteps.length), generationSteps.length - 1);
        setStatusMessage(generationSteps[stepIndex]);
      }
    }, 400);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `Perform a realistic virtual try-on. The user is wearing the following items from the AFRICAN BOY collection: ${selectedItems.map(i => i.name).join(', ')}. 
      Maintain the user's facial identity, body proportions, and pose. 
      Apply the clothing textures realistically, matching the lighting and shadows of the original photo.
      The output should be a high-quality, professional fashion photograph.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: userPhoto.split(',')[1],
                mimeType: 'image/png',
              },
            },
            { text: prompt },
          ],
        },
      });

      clearInterval(interval);
      setProgress(100);
      setStatusMessage('Look complete!');

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setTimeout(() => {
            setGeneratedImage(`data:image/png;base64,${part.inlineData.data}`);
            setStep('result');
          }, 500);
          break;
        }
      }
    } catch (error) {
      console.error('AI Generation failed:', error);
      clearInterval(interval);
      // Fallback for demo purposes if API fails or key is missing
      setTimeout(() => {
        setGeneratedImage(userPhoto); // Just show original for now if it fails
        setStep('result');
      }, 1000);
    }
  };

  const reset = () => {
    setStep('upload');
    setUserPhoto(null);
    setSelectedItems([]);
    setGeneratedImage(null);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-xl"
          />
          
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-5xl h-[85vh] bg-zinc-950 border border-white/10 rounded-[2rem] overflow-hidden flex flex-col shadow-2xl"
          >
            {/* Header */}
            <div className="flex flex-col border-b border-white/5">
              <div className="flex items-center justify-between p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-brand-yellow/10 flex items-center justify-center">
                    <User className="text-brand-yellow" size={20} />
                  </div>
                  <div>
                    <h2 className="text-xl font-black tracking-tighter italic uppercase">FIT ME <span className="text-brand-yellow">Studio</span></h2>
                    <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">AI Virtual Try-On Studio</p>
                  </div>
                </div>
                <button 
                  onClick={onClose}
                  className="p-2 hover:bg-white/10 rounded-full transition-colors text-zinc-400"
                >
                  <X size={24} />
                </button>
              </div>

              {/* Progress Indicator */}
              <div className="px-6 pb-6 flex items-center justify-between max-w-2xl mx-auto w-full">
                {[
                  { id: 'upload', label: 'Upload' },
                  { id: 'detecting', label: 'Analyze' },
                  { id: 'select', label: 'Select' },
                  { id: 'generating', label: 'Generate' },
                  { id: 'result', label: 'Result' }
                ].map((s, i, arr) => {
                  const stepOrder = ['upload', 'detecting', 'select', 'generating', 'result'];
                  const currentIndex = stepOrder.indexOf(step);
                  const stepIndex = stepOrder.indexOf(s.id as Step);
                  const isCompleted = stepIndex < currentIndex;
                  const isActive = stepIndex === currentIndex;

                  return (
                    <React.Fragment key={s.id}>
                      <div className="flex flex-col items-center gap-2 relative">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-black transition-all duration-500 ${
                          isActive ? 'bg-brand-yellow text-black scale-110 shadow-[0_0_15px_rgba(242,125,38,0.4)]' : 
                          isCompleted ? 'bg-green-500 text-white' : 'bg-zinc-900 text-zinc-600 border border-white/5'
                        }`}>
                          {isCompleted ? <Check size={14} strokeWidth={3} /> : i + 1}
                        </div>
                        <span className={`text-[8px] font-black uppercase tracking-widest absolute -bottom-5 whitespace-nowrap ${
                          isActive ? 'text-brand-yellow' : 'text-zinc-600'
                        }`}>
                          {s.label}
                        </span>
                      </div>
                      {i < arr.length - 1 && (
                        <div className="flex-1 h-[1px] mx-2 bg-zinc-900 relative">
                          <motion.div 
                            className="absolute inset-0 bg-brand-yellow"
                            initial={{ width: '0%' }}
                            animate={{ width: isCompleted ? '100%' : '0%' }}
                            transition={{ duration: 0.5 }}
                          />
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 mt-4">
              {step === 'upload' && (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-8">
                  <div className="relative">
                    <div className="absolute inset-0 bg-brand-yellow/20 blur-3xl rounded-full" />
                    <div className="relative w-32 h-32 rounded-full border-2 border-dashed border-brand-yellow/30 flex items-center justify-center">
                      <Upload className="text-brand-yellow animate-bounce" size={40} />
                    </div>
                  </div>
                  <div className="max-w-md space-y-4">
                    <h3 className="text-2xl font-black uppercase italic tracking-tight">Upload Your <span className="text-brand-yellow">Style Canvas</span></h3>
                    <p className="text-zinc-400 text-sm leading-relaxed">
                      To begin your AI try-on experience, upload a clear, full-body photo. For best results, use a well-lit environment and a neutral pose.
                    </p>
                  </div>
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="px-8 py-4 bg-brand-yellow text-black font-black uppercase tracking-widest text-sm rounded-full hover:scale-105 transition-transform shadow-[0_0_20px_rgba(242,125,38,0.3)]"
                  >
                    Select Photo
                  </button>
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handlePhotoUpload} 
                  />
                </div>
              )}

              {step === 'detecting' && (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-8">
                  <div className="relative w-64 h-80 bg-zinc-900 rounded-3xl overflow-hidden border border-white/5">
                    {userPhoto && <img src={userPhoto} className="w-full h-full object-cover opacity-50" />}
                    <motion.div 
                      initial={{ top: '0%' }}
                      animate={{ top: '100%' }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      className="absolute left-0 right-0 h-1 bg-brand-yellow shadow-[0_0_15px_#F27D26] z-10"
                    />
                    
                    {/* Detection Points Overlay */}
                    <div className="absolute inset-0 pointer-events-none">
                      {[...Array(12)].map((_, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, scale: 0 }}
                          animate={{ 
                            opacity: progress > (i * 8) ? [0, 1, 0] : 0,
                            scale: progress > (i * 8) ? [0.5, 1.2, 1] : 0
                          }}
                          transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.1 }}
                          className="absolute w-2 h-2 bg-brand-yellow rounded-full shadow-[0_0_8px_#F27D26]"
                          style={{
                            top: `${20 + Math.random() * 60}%`,
                            left: `${20 + Math.random() * 60}%`
                          }}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="space-y-4 w-full max-w-xs">
                    <div className="space-y-2">
                      <h3 className="text-xl font-black uppercase italic tracking-tight flex items-center gap-2 justify-center">
                        <Sparkles className="text-brand-yellow animate-pulse" size={20} />
                        AI Analyzing <span className="text-brand-yellow">Body Metrics</span>
                      </h3>
                      <p className="text-[10px] text-brand-yellow font-black uppercase tracking-[0.2em] animate-pulse">
                        {statusMessage}
                      </p>
                    </div>
                    
                    {/* Progress Bar */}
                    <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-brand-yellow shadow-[0_0_10px_#F27D26]"
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                      />
                    </div>
                    
                    <div className="flex gap-4 justify-center opacity-40">
                      <span className="text-[8px] text-zinc-400 uppercase tracking-widest font-bold">Pose</span>
                      <span className="text-[8px] text-zinc-400 uppercase tracking-widest font-bold">Skin</span>
                      <span className="text-[8px] text-zinc-400 uppercase tracking-widest font-bold">Fabric</span>
                    </div>
                  </div>
                </div>
              )}

              {step === 'select' && (
                <div className="h-full flex flex-col space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <button 
                        onClick={() => setStep('upload')}
                        className="p-2 hover:bg-white/5 rounded-full text-zinc-500 hover:text-white transition-colors"
                      >
                        <ChevronRight size={20} className="rotate-180" />
                      </button>
                      <h3 className="text-xl font-black uppercase italic tracking-tight">Select <span className="text-brand-yellow">Collection</span></h3>
                    </div>
                    <div className="flex gap-2">
                      {['All', 'Tops', 'Bottoms', 'Accessories'].map(cat => (
                        <button key={cat} className="px-4 py-1.5 text-[10px] font-black uppercase tracking-widest border border-white/10 rounded-full hover:bg-white/5 transition-colors">
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-8 min-h-0">
                    <div className="lg:col-span-1 space-y-6">
                      <div className="aspect-[3/4] bg-zinc-900 rounded-3xl overflow-hidden border border-white/5 relative shadow-xl">
                        {userPhoto && <img src={userPhoto} className="w-full h-full object-cover" />}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                        <div className="absolute bottom-4 left-4">
                          <span className="px-3 py-1 bg-brand-yellow/20 backdrop-blur-md border border-brand-yellow/30 rounded-full text-[10px] font-black uppercase tracking-widest text-brand-yellow">
                            Canvas Ready
                          </span>
                        </div>
                      </div>
                      
                      <div className="p-5 bg-zinc-900/50 rounded-3xl border border-white/5 space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Selection ({selectedItems.length})</h4>
                          {selectedItems.length > 0 && (
                            <button onClick={() => setSelectedItems([])} className="text-[8px] font-black uppercase tracking-widest text-brand-yellow hover:underline">Clear</button>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {selectedItems.length === 0 ? (
                            <p className="text-[10px] text-zinc-600 italic">Select items from the collection to try them on...</p>
                          ) : (
                            selectedItems.map(item => (
                              <div key={item.id} className="px-2 py-1 bg-brand-yellow/10 border border-brand-yellow/20 rounded-lg flex items-center gap-2">
                                <span className="text-[10px] font-bold text-brand-yellow uppercase truncate max-w-[80px]">{item.name}</span>
                                <button onClick={() => toggleItem(item)} className="text-brand-yellow hover:text-white">
                                  <X size={10} />
                                </button>
                              </div>
                            ))
                          )}
                        </div>
                      </div>

                      <button 
                        disabled={selectedItems.length === 0}
                        onClick={handleGenerate}
                        className="w-full py-4 bg-brand-yellow disabled:bg-zinc-800 disabled:text-zinc-500 text-black font-black uppercase tracking-widest text-sm rounded-2xl transition-all flex items-center justify-center gap-2 group shadow-[0_0_20px_rgba(242,125,38,0.2)]"
                      >
                        Generate Look
                        <Sparkles size={18} className="group-hover:rotate-12 transition-transform" />
                      </button>
                    </div>

                    <div className="lg:col-span-3 overflow-y-auto pr-2 no-scrollbar">
                      {isLoadingProducts ? (
                        <div className="h-full flex items-center justify-center">
                          <Loader2 className="text-brand-yellow animate-spin" size={32} />
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4">
                          {products.map(product => {
                            const isSelected = selectedItems.find(p => p.id === product.id);
                            return (
                              <motion.div 
                                key={product.id}
                                whileHover={{ y: -4 }}
                                onClick={() => toggleItem(product)}
                                className={`group relative aspect-square bg-zinc-900 rounded-3xl overflow-hidden border cursor-pointer transition-all ${isSelected ? 'border-brand-yellow ring-1 ring-brand-yellow' : 'border-white/5 hover:border-white/20'}`}
                              >
                                <img src={product.image_url} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-60 group-hover:opacity-100 transition-opacity" />
                                <div className="absolute bottom-3 left-3 right-3">
                                  <p className="text-[9px] font-black uppercase text-brand-yellow mb-0.5">{product.category}</p>
                                  <p className="text-[10px] font-bold uppercase truncate">{product.name}</p>
                                </div>
                                {isSelected && (
                                  <div className="absolute top-3 right-3 w-6 h-6 bg-brand-yellow rounded-full flex items-center justify-center shadow-lg">
                                    <Check size={14} className="text-black" strokeWidth={3} />
                                  </div>
                                )}
                              </motion.div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {step === 'generating' && (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-8">
                  <div className="relative w-64 h-80 bg-zinc-900 rounded-3xl overflow-hidden border border-white/5">
                    {userPhoto && <img src={userPhoto} className="w-full h-full object-cover opacity-30 blur-sm" />}
                    
                    {/* Shimmer Effect */}
                    <motion.div
                      animate={{
                        left: ['-100%', '200%'],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-brand-yellow/20 to-transparent skew-x-12"
                    />

                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="relative">
                        <motion.div 
                          animate={{ rotate: 360 }}
                          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                          className="w-32 h-32 rounded-full border-2 border-dashed border-brand-yellow/40"
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Sparkles className="text-brand-yellow animate-pulse" size={32} />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6 w-full max-w-sm">
                    <div className="space-y-2">
                      <h3 className="text-2xl font-black uppercase italic tracking-tight">Crafting Your <span className="text-brand-yellow">Digital Look</span></h3>
                      <p className="text-brand-yellow text-[10px] font-black uppercase tracking-[0.3em] animate-pulse">
                        {statusMessage}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-zinc-500">
                        <span>Neural Processing</span>
                        <span>{Math.round(progress)}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full bg-brand-yellow shadow-[0_0_15px_#F27D26]"
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                          transition={{ type: "spring", stiffness: 50 }}
                        />
                      </div>
                    </div>

                    <p className="text-zinc-500 text-[10px] leading-relaxed uppercase tracking-widest font-bold">
                      Matching lighting, textures, and proportions for a realistic fit...
                    </p>
                  </div>
                </div>
              )}

              {step === 'result' && (
                <div className="h-full grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="relative aspect-[3/4] bg-zinc-900 rounded-[2.5rem] overflow-hidden border border-white/10 shadow-2xl">
                    {generatedImage && <img src={generatedImage} className="w-full h-full object-cover" />}
                    <div className="absolute top-6 left-6">
                      <div className="px-4 py-2 bg-black/40 backdrop-blur-xl border border-white/10 rounded-full flex items-center gap-2">
                        <div className="w-2 h-2 bg-brand-yellow rounded-full animate-pulse" />
                        <span className="text-[10px] font-black uppercase tracking-widest">AI Generated</span>
                      </div>
                    </div>
                    <div className="absolute bottom-6 right-6">
                      <p className="text-[10px] font-black uppercase tracking-widest text-white/40 italic">Styled with FIT ME</p>
                    </div>
                  </div>

                  <div className="flex flex-col justify-center space-y-8">
                    <div className="space-y-2">
                      <h3 className="text-3xl font-black uppercase italic tracking-tighter">The Future <span className="text-brand-yellow">Fits You</span></h3>
                      <p className="text-zinc-400">Your custom AFRICAN BOY look is ready. How do you want to proceed?</p>
                    </div>

                    <div className="grid grid-cols-1 gap-4">
                      <button className="w-full py-5 bg-brand-yellow text-black font-black uppercase tracking-widest text-sm rounded-2xl flex items-center justify-center gap-3 hover:scale-[1.02] transition-transform shadow-[0_0_30px_rgba(242,125,38,0.3)]">
                        <ShoppingBag size={20} />
                        Add Full Outfit to Cart
                      </button>
                      <div className="grid grid-cols-2 gap-4">
                        <button className="py-4 bg-zinc-900 border border-white/10 text-white font-black uppercase tracking-widest text-[10px] rounded-2xl flex items-center justify-center gap-2 hover:bg-zinc-800 transition-colors">
                          <Download size={16} />
                          Download
                        </button>
                        <button className="py-4 bg-zinc-900 border border-white/10 text-white font-black uppercase tracking-widest text-[10px] rounded-2xl flex items-center justify-center gap-2 hover:bg-zinc-800 transition-colors">
                          <Share2 size={16} />
                          Share Style
                        </button>
                      </div>
                    </div>

                    <div className="p-6 bg-zinc-900/50 rounded-3xl border border-white/5 space-y-4">
                      <h4 className="text-xs font-black uppercase tracking-widest text-brand-yellow flex items-center gap-2">
                        <Sparkles size={14} />
                        AI Recommendations
                      </h4>
                      <div className="grid grid-cols-3 gap-3">
                        {products.slice(0, 3).map(p => (
                          <div key={p.id} className="aspect-square bg-zinc-800 rounded-xl overflow-hidden border border-white/5">
                            <img src={p.image_url} className="w-full h-full object-cover opacity-60 hover:opacity-100 transition-opacity cursor-pointer" />
                          </div>
                        ))}
                      </div>
                      <p className="text-[10px] text-zinc-500 leading-relaxed">
                        Based on your body shape and selected pose, we recommend these accessories to complete your look.
                      </p>
                    </div>

                      <div className="flex flex-col items-center gap-4">
                        <button 
                          onClick={() => setStep('select')}
                          className="px-6 py-3 bg-white/5 border border-white/10 text-white font-black uppercase tracking-widest text-[10px] rounded-full hover:bg-white/10 transition-colors"
                        >
                          Modify Selection
                        </button>
                        <button 
                          onClick={reset}
                          className="text-[10px] font-black uppercase tracking-widest text-zinc-500 hover:text-brand-yellow transition-colors"
                        >
                          Start Over with New Photo
                        </button>
                      </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
