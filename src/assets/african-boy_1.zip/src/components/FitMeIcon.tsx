import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function FitMeIcon() {
  const [clothIndex, setClothIndex] = useState(0);
  
  // Dramatic colors for "changing clothes"
  const clothes = [
    { color: '#F27D26', pattern: 'bg-brand-yellow' }, // Brand Yellow
    { color: '#FFFFFF', pattern: 'bg-white' },        // White
    { color: '#3b82f6', pattern: 'bg-blue-500' },     // Blue
    { color: '#ef4444', pattern: 'bg-red-500' },      // Red
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setClothIndex((prev) => (prev + 1) % clothes.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative w-10 h-12 flex items-center justify-center">
      {/* Realistic Human Silhouette */}
      <svg viewBox="0 0 24 24" fill="none" className="w-full h-full drop-shadow-[0_0_8px_rgba(255,255,255,0.2)]">
        {/* Head - More natural proportions */}
        <circle cx="12" cy="4.5" r="2.2" fill="currentColor" />
        
        {/* Body/Torso & Limbs - This is what "changes clothes" */}
        <AnimatePresence mode="wait">
          <motion.g
            key={clothIndex}
            initial={{ opacity: 0, scale: 0.9, filter: 'brightness(2)' }}
            animate={{ opacity: 1, scale: 1, filter: 'brightness(1)' }}
            exit={{ opacity: 0, scale: 1.1, filter: 'brightness(0.5)' }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
          >
            {/* Torso & Arms - Male Physique (Broader Shoulders) */}
            <path
              d="M12 7.5c-3.2 0-5.5 1.5-5.5 4 0 1.2 0.8 2.5 1.2 3.5l-0.5 5c-0.1 0.8 0.5 1.5 1.3 1.5h7c0.8 0 1.4-0.7 1.3-1.5l-0.5-5c0.4-1 1.2-2.3 1.2-3.5 0-2.5-2.3-4-5.5-4z"
              fill={clothes[clothIndex].color}
            />
            {/* Arms - More muscular definition */}
            <path
              d="M6.5 11.5l-1.8 4.5c-0.2 0.6 0.2 1.2 0.8 1.2s1.1-0.3 1.2-0.9l1-3.8 M17.5 11.5l1.8 4.5c0.2 0.6-0.2 1.2-0.8 1.2s-1.1-0.3-1.2-0.9l-1-3.8"
              fill={clothes[clothIndex].color}
            />
            {/* Legs - Male proportions */}
            <path
              d="M9.2 21.5h2v2.5c0 0.3-0.2 0.5-0.5 0.5s-0.5-0.2-0.5-0.5v-2.5z M12.8 21.5h2v2.5c0 0.3-0.2 0.5-0.5 0.5s-0.5-0.2-0.5-0.5v-2.5z"
              fill={clothes[clothIndex].color}
            />
          </motion.g>
        </AnimatePresence>

        {/* Subtle highlights for realism - Chest definition */}
        <path 
          d="M9 10.5c1.5 0.5 4.5 0.5 6 0" 
          stroke="white" 
          strokeWidth="0.4" 
          strokeLinecap="round" 
          className="opacity-40"
        />
        <path 
          d="M12 10v4" 
          stroke="white" 
          strokeWidth="0.2" 
          strokeLinecap="round" 
          className="opacity-20"
        />
      </svg>
      
      {/* Sparkle effect when changing */}
      <AnimatePresence>
        <motion.div
          key={`sparkle-${clothIndex}`}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: [0, 1.5, 0], opacity: [0, 1, 0] }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="w-full h-full bg-white/20 blur-md rounded-full" />
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
