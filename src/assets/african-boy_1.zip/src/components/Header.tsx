import { Search, ShoppingCart, Menu, User, Zap } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useState } from 'react';
import CartDrawer from './CartDrawer';
import { useCountry } from '../context/CountryContext';
import { motion } from 'motion/react';
import FitMeModal from './FitMeModal';
import FitMeIcon from './FitMeIcon';

export default function Header() {
  const { cartCount } = useCart();
  const { selectedCountry } = useCountry();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isFitMeOpen, setIsFitMeOpen] = useState(false);

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-brand-black/50 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <Menu size={24} />
            </button>
            {selectedCountry && (
              <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-zinc-900 rounded-full border border-white/5">
                <span className="text-sm">{selectedCountry.flag_emoji}</span>
                <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{selectedCountry.code}</span>
              </div>
            )}
          </div>
          
          <div className="flex flex-col items-center">
            <span className="text-brand-yellow font-black text-xl tracking-tighter italic">AFRICAN BOY</span>
          </div>

          <div className="flex items-center gap-1 sm:gap-2">
            <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <Search size={22} />
            </button>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors relative"
            >
              <ShoppingCart size={22} />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-brand-yellow text-black text-[10px] font-black flex items-center justify-center rounded-full">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      <FitMeModal isOpen={isFitMeOpen} onClose={() => setIsFitMeOpen(false)} />

      <motion.button
        onClick={() => setIsFitMeOpen(true)}
        initial={{ opacity: 0, scale: 0, y: 20 }}
        animate={{ 
          opacity: 1, 
          scale: 1, 
          y: 0,
          boxShadow: [
            "0 0 0px rgba(242, 125, 38, 0.4)",
            "0 0 35px rgba(242, 125, 38, 0.7)",
            "0 0 0px rgba(242, 125, 38, 0.4)"
          ]
        }}
        transition={{
          boxShadow: {
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut"
          }
        }}
        whileHover={{ scale: 1.15, rotate: [0, -5, 5, 0] }}
        whileTap={{ scale: 0.9 }}
        className="fixed bottom-10 right-10 z-[60] flex items-center gap-4 px-8 py-5 rounded-[2.5rem] bg-brand-yellow text-black border-2 border-white/30 overflow-hidden group shadow-2xl"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] pointer-events-none" />
        <div className="relative">
          <FitMeIcon />
          <motion.div
            animate={{ scale: [1, 2, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="absolute -top-2 -right-2 w-3 h-3 bg-white rounded-full shadow-[0_0_10px_#fff]"
          />
        </div>
        <div className="flex flex-col items-start leading-none">
          <span className="text-sm font-black uppercase tracking-tighter">FIT ME</span>
          <span className="text-[10px] font-black opacity-80 uppercase tracking-widest">AI STUDIO</span>
        </div>
      </motion.button>

      <style>{`
        @keyframes shimmer {
          100% { transform: translateX(100%); }
        }
      `}</style>
    </>
  );
}
