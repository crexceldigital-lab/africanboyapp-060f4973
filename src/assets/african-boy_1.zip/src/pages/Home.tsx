import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { Product, NavTab } from '../types';
import ProductCard from '../components/ProductCard';
import { ArrowRight } from 'lucide-react';

interface HomeProps {
  onNavigate: (tab: NavTab) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => setFeaturedProducts(data.slice(0, 4)));
  }, []);

  return (
    <div className="pb-24 pt-16">
      {/* Hero Section */}
      <section className="relative h-[85vh] w-full overflow-hidden bg-black flex items-center justify-center">
        {/* Background Image / Overlay */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black z-10" />
          <div className="absolute inset-0 bg-black/40 z-10" />
          <img 
            src="https://images.unsplash.com/photo-1493225255756-d9584f8606e9?auto=format&fit=crop&q=80&w=2070" 
            alt="Hero Background"
            className="w-full h-full object-cover opacity-60"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Branding Content */}
        <div className="relative z-20 flex flex-col items-center text-center px-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="relative mb-8"
          >
            {/* Curved Text Simulation */}
            <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-[300px] h-[100px] flex items-center justify-center">
              <span className="text-white/20 text-4xl font-black tracking-[0.5em] uppercase pointer-events-none">
                AFRICAN BOY
              </span>
            </div>

            {/* Golden Chain Circle Frame */}
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full border-[12px] border-brand-yellow shadow-[0_0_50px_rgba(242,125,38,0.3)] overflow-hidden flex items-center justify-center bg-zinc-900">
              <img 
                src="https://images.unsplash.com/photo-1503443207922-dff7d543fd0e?auto=format&fit=crop&q=80&w=1000" 
                alt="Jux Portrait"
                className="w-full h-full object-cover grayscale brightness-110 contrast-125"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="max-w-2xl"
          >
            <h1 className="text-5xl md:text-7xl font-black tracking-tighter leading-none mb-4 italic">
              THE <span className="text-brand-yellow">LEGACY</span> CONTINUES
            </h1>
            <p className="text-gray-400 text-sm md:text-base mb-8 font-medium tracking-wide uppercase">
              Official Merchandise • Exclusive Content • VIP Experience
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={() => onNavigate('shop')}
                className="w-full sm:w-auto px-10 py-4 bg-brand-yellow text-black font-black uppercase tracking-widest text-sm rounded-full hover:scale-105 transition-transform shadow-[0_0_20px_rgba(242,125,38,0.4)]"
              >
                Shop Collection
              </button>
              <button 
                onClick={() => onNavigate('video')}
                className="w-full sm:w-auto px-10 py-4 bg-white/5 border border-white/10 text-white font-black uppercase tracking-widest text-sm rounded-full hover:bg-white/10 transition-colors"
              >
                Explore Media
              </button>
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-zinc-500"
        >
          <div className="w-[1px] h-12 bg-gradient-to-b from-brand-yellow to-transparent mx-auto" />
        </motion.div>
      </section>

      {/* Spotlight Section */}
      <section className="px-6 py-12">
        <div className="flex justify-between items-end mb-8">
          <div>
            <span className="text-brand-yellow text-xs font-bold tracking-widest uppercase">Spotlight</span>
            <h2 className="text-3xl font-black tracking-tight">LATEST NEWS</h2>
          </div>
          <button 
            onClick={() => onNavigate('video')}
            className="text-xs font-bold text-gray-500 hover:text-white transition-colors"
          >
            SHOW ALL
          </button>
          <motion.div
            whileHover={{ y: -5 }}
            className="relative h-64 rounded-3xl overflow-hidden group border border-white/5 bg-zinc-900"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent p-6 flex flex-col justify-end">
              <span className="bg-brand-yellow text-black text-[10px] font-black px-2 py-1 rounded w-fit mb-2">UPDATES</span>
              <h3 className="text-xl font-bold leading-tight">Welcome to African Boy</h3>
              <p className="text-xs text-gray-400 mt-2">Just now</p>
            </div>
          </motion.div>

          <motion.div
            whileHover={{ y: -5 }}
            className="relative h-64 rounded-3xl overflow-hidden group border border-white/5 bg-zinc-900"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent p-6 flex flex-col justify-end">
              <span className="bg-brand-yellow text-black text-[10px] font-black px-2 py-1 rounded w-fit mb-2">LIFESTYLE</span>
              <h3 className="text-xl font-bold leading-tight">New Collection Coming Soon</h3>
              <p className="text-xs text-gray-400 mt-2">Recently</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Merch */}
      <section className="px-6 py-12 bg-zinc-950">
        <div className="flex justify-between items-end mb-8">
          <div>
            <span className="text-brand-yellow text-xs font-bold tracking-widest uppercase">Collection</span>
            <h2 className="text-3xl font-black tracking-tight">FOR MEN</h2>
          </div>
          <button 
            onClick={() => onNavigate('shop')}
            className="text-xs font-bold text-gray-500 hover:text-white transition-colors"
          >
            SHOW ALL
          </button>
          {featuredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
    </div>
  );
}
