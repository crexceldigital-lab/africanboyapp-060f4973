import React, { useState } from 'react';
import { useCountry } from '../context/CountryContext';
import { motion } from 'motion/react';
import { Mail, Lock, Smartphone, User, Globe, ChevronRight, Loader2 } from 'lucide-react';

export default function Login() {
  const { login, signup, countries } = useCountry();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    identifier: '',
    password: '',
    email: '',
    phone_number: '',
    full_name: '',
    country_id: 0
  });

  // Sync country_id once countries load
  React.useEffect(() => {
    if (countries.length > 0 && formData.country_id === 0) {
      setFormData(prev => ({ ...prev, country_id: countries[0].id }));
    }
  }, [countries]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      let success = false;
      if (isLogin) {
        success = await login(formData.identifier, formData.password);
      } else {
        success = await signup({
          email: formData.email,
          phone_number: formData.phone_number,
          password: formData.password,
          full_name: formData.full_name,
          country_id: formData.country_id || countries[0]?.id || 1
        });
      }

      if (!success) {
        setError(isLogin ? 'Invalid credentials' : 'Signup failed. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black px-6 py-20">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-zinc-950 rounded-[2.5rem] p-8 border border-white/5 shadow-2xl"
      >
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-brand-yellow/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-brand-yellow/20">
            <User size={40} className="text-brand-yellow" />
          </div>
          <h1 className="text-3xl font-black italic uppercase tracking-tighter">
            {isLogin ? 'Welcome' : 'Join the'} <span className="text-brand-yellow">Movement</span>
          </h1>
          <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mt-2">
            {isLogin ? 'Sign in to your account' : 'Create your AFB fan account'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isLogin ? (
            <>
              <div className="relative">
                <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <input 
                  type="text"
                  required
                  placeholder="Email or Phone Number"
                  value={formData.identifier}
                  onChange={(e) => setFormData({ ...formData, identifier: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all"
                />
              </div>
              <div className="relative">
                <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <input 
                  type="password"
                  required
                  placeholder="Password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all"
                />
              </div>
            </>
          ) : (
            <>
              <div className="relative">
                <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <input 
                  type="text"
                  required
                  placeholder="Full Name"
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all"
                />
              </div>
              <div className="relative">
                <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <input 
                  type="email"
                  required
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all"
                />
              </div>
              <div className="relative">
                <Smartphone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <input 
                  type="tel"
                  required
                  placeholder="Phone Number (e.g. +255...)"
                  value={formData.phone_number}
                  onChange={(e) => setFormData({ ...formData, phone_number: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all"
                />
              </div>
              <div className="relative">
                <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <input 
                  type="password"
                  required
                  placeholder="Create Password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all"
                />
              </div>
              <div className="relative">
                <Globe size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <select 
                  value={formData.country_id}
                  onChange={(e) => setFormData({ ...formData, country_id: parseInt(e.target.value) })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-12 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all appearance-none cursor-pointer"
                >
                  {countries.map(c => (
                    <option key={c.id} value={c.id}>{c.flag_emoji} {c.name}</option>
                  ))}
                </select>
              </div>
            </>
          )}

          {error && (
            <motion.p 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-red-500 text-[10px] font-black uppercase tracking-widest text-center"
            >
              {error}
            </motion.p>
          )}

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-brand-yellow text-black font-black py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-white transition-all shadow-[0_10px_20px_rgba(242,183,5,0.2)] disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : (
              <>
                {isLogin ? 'SIGN IN' : 'CREATE ACCOUNT'} <ChevronRight size={20} />
              </>
            )}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-xs font-bold text-gray-500 hover:text-brand-yellow transition-colors uppercase tracking-widest"
          >
            {isLogin ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
