import { useState, useEffect } from 'react';
import { Purchase } from '../types';
import { motion } from 'motion/react';
import { User as UserIcon, Mail, Crown, ShoppingBag, Edit2, Save, X, Truck, Globe, LogOut, ChevronDown } from 'lucide-react';
import { useCountry } from '../context/CountryContext';

export default function Profile() {
  const { user, countries, refreshUser, formatPrice, logout, loading: countryLoading } = useCountry();
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({ full_name: '', email: '', country_id: 0 });
  const [loading, setLoading] = useState(true);

  // Initialize form when editing starts or user loads
  useEffect(() => {
    if (user && !isEditing) {
      setEditForm({ 
        full_name: user.full_name, 
        email: user.email, 
        country_id: user.country_id 
      });
    }
  }, [user, isEditing]);

  useEffect(() => {
    const fetchPurchases = async () => {
      try {
        const purchaseRes = await fetch('/api/purchases');
        if (purchaseRes.ok) {
          const purchaseData = await purchaseRes.json();
          setPurchases(purchaseData);
        }
      } catch (error) {
        console.error('Error fetching purchases:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchPurchases();
  }, []);

  const handleSave = async () => {
    if (!user) return;
    try {
      const res = await fetch('/api/user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: user.id, ...editForm })
      });
      if (res.ok) {
        setIsEditing(false);
        await refreshUser();
      }
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  if (loading || countryLoading) return (
    <div className="min-h-screen flex items-center justify-center bg-black">
      <div className="animate-pulse flex flex-col items-center gap-4">
        <div className="w-12 h-12 rounded-full border-2 border-brand-yellow border-t-transparent animate-spin" />
        <p className="text-brand-yellow font-bold text-xs tracking-widest uppercase">Loading Profile...</p>
      </div>
    </div>
  );

  if (!user) return (
    <div className="min-h-screen flex items-center justify-center bg-black px-6">
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto text-red-500">
          <X size={32} />
        </div>
        <h2 className="text-2xl font-black italic uppercase tracking-tight">User Not Found</h2>
        <p className="text-gray-500 text-sm">Please try logging in again.</p>
        <button className="btn-primary w-full">GO TO LOGIN</button>
      </div>
    </div>
  );

  return (
    <div className="pb-24 pt-20 px-6 max-w-2xl mx-auto">
      <div className="mb-12 flex justify-between items-end">
        <div>
          <span className="text-brand-yellow text-xs font-bold tracking-widest uppercase">My Account</span>
          <h1 className="text-4xl font-black tracking-tighter italic uppercase">User <span className="text-brand-yellow">Profile</span></h1>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setIsEditing(!isEditing)}
            className={`p-3 rounded-2xl border transition-all ${isEditing ? 'bg-brand-yellow text-black border-brand-yellow' : 'bg-zinc-900 border-white/5 text-brand-yellow hover:bg-zinc-800'}`}
          >
            {isEditing ? <X size={20} /> : <Edit2 size={20} />}
          </button>
        </div>
      </div>

      {/* Profile Info Card */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-zinc-950 rounded-3xl p-8 border border-white/5 mb-8 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <UserIcon size={120} />
        </div>

        <div className="flex items-center gap-6 mb-10 relative z-10">
          <div className="w-24 h-24 rounded-full bg-brand-yellow/10 flex items-center justify-center text-brand-yellow border-2 border-brand-yellow/20 shadow-[0_0_30px_rgba(242,183,5,0.1)]">
            <UserIcon size={48} />
          </div>
          <div>
            <h2 className="text-3xl font-black italic tracking-tight leading-none mb-2">{user.full_name}</h2>
            <div className="flex items-center gap-2 text-brand-yellow text-xs font-bold uppercase tracking-widest">
              <Crown size={14} />
              {user.vip_tier} MEMBER
            </div>
          </div>
        </div>

        <div className="space-y-6 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex flex-col gap-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Full Name</label>
              {isEditing ? (
                <div className="relative">
                  <UserIcon size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input 
                    type="text"
                    value={editForm.full_name}
                    onChange={(e) => setEditForm({ ...editForm, full_name: e.target.value })}
                    className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all"
                    placeholder="Enter full name"
                  />
                </div>
              ) : (
                <div className="flex items-center gap-3 bg-zinc-900/50 border border-white/5 rounded-2xl px-5 py-4 text-sm font-bold text-white/90">
                  <UserIcon size={18} className="text-brand-yellow" />
                  {user.full_name}
                </div>
              )}
            </div>

            <div className="flex flex-col gap-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Email Address</label>
              {isEditing ? (
                <div className="relative">
                  <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input 
                    type="email"
                    value={editForm.email}
                    onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                    className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all"
                    placeholder="Enter email"
                  />
                </div>
              ) : (
                <div className="flex items-center gap-3 bg-zinc-900/50 border border-white/5 rounded-2xl px-5 py-4 text-sm font-bold text-white/90">
                  <Mail size={18} className="text-brand-yellow" />
                  {user.email}
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center ml-1">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Country / Region</label>
              {isEditing && <span className="text-[9px] font-black text-brand-yellow uppercase tracking-widest">Switch Country</span>}
            </div>
            {isEditing ? (
              <div className="relative">
                <Globe size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <select 
                  value={editForm.country_id}
                  onChange={(e) => setEditForm({ ...editForm, country_id: parseInt(e.target.value) })}
                  className="w-full bg-zinc-900 border border-white/10 rounded-2xl pl-12 pr-12 py-4 text-sm font-bold focus:outline-none focus:border-brand-yellow transition-all appearance-none cursor-pointer"
                >
                  {countries.map(c => (
                    <option key={c.id} value={c.id}>{c.flag_emoji} {c.name}</option>
                  ))}
                </select>
                <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none" />
              </div>
            ) : (
              <div className="flex items-center gap-3 bg-zinc-900/50 border border-white/5 rounded-2xl px-5 py-4 text-sm font-bold text-white/90">
                <Globe size={18} className="text-brand-yellow" />
                <span className="flex-1">{user.country_name}</span>
                <span className="text-[10px] bg-brand-yellow/10 text-brand-yellow px-2 py-1 rounded-md border border-brand-yellow/20 font-black">{user.currency_code}</span>
              </div>
            )}
          </div>

          {isEditing && (
            <motion.button 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              onClick={handleSave}
              className="w-full mt-4 bg-brand-yellow text-black font-black py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-white transition-all shadow-[0_10px_20px_rgba(242,183,5,0.2)]"
            >
              <Save size={20} /> SAVE PROFILE CHANGES
            </motion.button>
          )}
        </div>
      </motion.div>
      
      {/* Delivery Rates Card */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-zinc-950 rounded-3xl p-8 border border-white/5 mb-8"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-black italic tracking-tight flex items-center gap-3 uppercase">
            <Truck size={22} className="text-brand-yellow" />
            Delivery <span className="text-brand-yellow">Rates</span>
          </h2>
          <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Standard Shipping</span>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-5 bg-zinc-900/50 rounded-2xl border border-white/5 hover:border-brand-yellow/30 transition-all group">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest block mb-1">Dar Es Salaam</span>
            <div className="text-xl font-black text-white group-hover:text-brand-yellow transition-colors">{formatPrice(3000)}</div>
          </div>
          <div className="p-5 bg-zinc-900/50 rounded-2xl border border-white/5 hover:border-brand-yellow/30 transition-all group">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest block mb-1">Other Regions</span>
            <div className="text-xl font-black text-white group-hover:text-brand-yellow transition-colors">{formatPrice(10000)}</div>
          </div>
        </div>
      </motion.div>

      {/* Purchase History */}
      <div className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-black italic tracking-tight flex items-center gap-3 uppercase">
            <ShoppingBag size={26} className="text-brand-yellow" />
            Order <span className="text-brand-yellow">History</span>
          </h2>
          <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{purchases.length} ORDERS</span>
        </div>
        
        <div className="space-y-4">
          {purchases.length > 0 ? (
            purchases.map((purchase, idx) => (
              <motion.div 
                key={purchase.id}
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.05 }}
                className="bg-zinc-900/50 rounded-2xl p-5 border border-white/5 flex justify-between items-center hover:bg-zinc-900 transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-zinc-800 flex items-center justify-center text-brand-yellow">
                    <ShoppingBag size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-white">{purchase.product_name}</h4>
                    <p className="text-[10px] text-gray-500 mt-1 font-medium">
                      {new Date(purchase.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-brand-yellow font-black text-lg">{formatPrice(purchase.amount)}</div>
                  <div className="text-[9px] text-emerald-500 font-black uppercase tracking-widest mt-1 bg-emerald-500/10 px-2 py-1 rounded-md inline-block border border-emerald-500/20">COMPLETED</div>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="text-center py-16 bg-zinc-900/30 rounded-[2rem] border border-dashed border-white/10">
              <ShoppingBag size={48} className="mx-auto text-zinc-800 mb-4" />
              <p className="text-gray-500 text-sm font-bold uppercase tracking-widest">No purchases yet.</p>
              <button className="text-brand-yellow text-xs font-black mt-4 hover:text-white transition-colors uppercase tracking-widest">Start Shopping Now</button>
            </div>
          )}
        </div>
      </div>

      {/* Danger Zone / Logout */}
      <div className="pt-8 border-t border-white/5">
        <button 
          onClick={logout}
          className="w-full py-4 rounded-2xl border border-red-500/20 text-red-500 font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-red-500/10 transition-all"
        >
          <LogOut size={16} /> SIGN OUT OF ACCOUNT
        </button>
      </div>
    </div>
  );
}
