import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Package, 
  Plus, 
  Edit2, 
  Trash2, 
  Search, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2,
  X,
  Upload,
  Save,
  Image as ImageIcon,
  Calendar
} from 'lucide-react';
import { Product, AppEvent } from '../types';

type AdminTab = 'products' | 'inventory' | 'gallery' | 'events';

export default function Admin() {
  const [activeTab, setActiveTab] = useState<AdminTab>('products');
  const [products, setProducts] = useState<Product[]>([]);
  const [gallery, setGallery] = useState<any[]>([]);
  const [events, setEvents] = useState<AppEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isGalleryModalOpen, setIsGalleryModalOpen] = useState(false);
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [editingGalleryItem, setEditingGalleryItem] = useState<any | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editingEvent, setEditingEvent] = useState<AppEvent | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    category: 'Jeans',
    image_url: '',
    description: '',
    stock_quantity: ''
  });

  const [galleryFormData, setGalleryFormData] = useState({
    image_url: '',
    title: ''
  });

  const [eventFormData, setEventFormData] = useState({
    title: '',
    date: '',
    location: '',
    price: '',
    image_url: ''
  });

  const categories = ['Jeans', 'T-Shirt', 'Hoods', 'Caps', 'Phone Case', 'Footwear'];

  const handleUpdateStock = async (id: number, newStock: number) => {
    if (newStock < 0) return;
    
    // Optimistic update
    setProducts(prev => prev.map(p => p.id === id ? { ...p, stock_quantity: newStock } : p));

    try {
      const product = products.find(p => p.id === id);
      if (!product) return;

      await fetch(`/api/admin/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...product,
          stock_quantity: newStock
        })
      });
    } catch (err) {
      console.error('Failed to update stock');
      fetchProducts(); // Revert on error
    }
  };

  useEffect(() => {
    fetchProducts();
    fetchGallery();
    fetchEvents();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await fetch('/api/products');
      const data = await response.json();
      setProducts(data);
    } catch (err) {
      console.error('Failed to fetch products');
    } finally {
      setLoading(false);
    }
  };

  const fetchGallery = async () => {
    try {
      const response = await fetch('/api/gallery');
      const data = await response.json();
      setGallery(data);
    } catch (err) {
      console.error('Failed to fetch gallery');
    }
  };

  const fetchEvents = async () => {
    try {
      const response = await fetch('/api/events');
      const data = await response.json();
      setEvents(data);
    } catch (err) {
      console.error('Failed to fetch events');
    }
  };

  const handleOpenModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        price: product.price.toString(),
        category: product.category,
        image_url: product.image_url,
        description: product.description,
        stock_quantity: product.stock_quantity.toString()
      });
    } else {
      setEditingProduct(null);
      setFormData({
        name: '',
        price: '',
        category: 'Jeans',
        image_url: '',
        description: '',
        stock_quantity: '0'
      });
    }
    setIsModalOpen(true);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, image_url: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGalleryImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setGalleryFormData({ ...galleryFormData, image_url: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEventImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEventFormData({ ...eventFormData, image_url: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleOpenGalleryModal = (item?: any) => {
    if (item) {
      setEditingGalleryItem(item);
      setGalleryFormData({
        image_url: item.image_url,
        title: item.title || ''
      });
    } else {
      setEditingGalleryItem(null);
      setGalleryFormData({
        image_url: '',
        title: ''
      });
    }
    setIsGalleryModalOpen(true);
  };

  const handleOpenEventModal = (event?: AppEvent) => {
    if (event) {
      setEditingEvent(event);
      setEventFormData({
        title: event.title,
        date: event.date,
        location: event.location,
        price: event.price.toString(),
        image_url: event.image_url
      });
    } else {
      setEditingEvent(null);
      setEventFormData({
        title: '',
        date: '',
        location: '',
        price: '',
        image_url: ''
      });
    }
    setIsEventModalOpen(true);
  };

  const handleGallerySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const url = editingGalleryItem ? `/api/admin/gallery/${editingGalleryItem.id}` : '/api/admin/gallery';
    const method = editingGalleryItem ? 'PUT' : 'POST';

    try {
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(galleryFormData)
      });

      if (response.ok) {
        setIsGalleryModalOpen(false);
        setGalleryFormData({ image_url: '', title: '' });
        setEditingGalleryItem(null);
        fetchGallery();
      }
    } catch (err) {
      console.error('Failed to save gallery item');
    }
  };

  const handleDeleteGallery = async (id: number) => {
    if (!confirm('Are you sure you want to delete this image from gallery?')) return;
    try {
      const response = await fetch(`/api/admin/gallery/${id}`, { method: 'DELETE' });
      if (response.ok) {
        fetchGallery();
      }
    } catch (err) {
      console.error('Failed to delete from gallery');
    }
  };

  const handleEventSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const url = editingEvent ? `/api/admin/events/${editingEvent.id}` : '/api/admin/events';
    const method = editingEvent ? 'PUT' : 'POST';

    try {
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...eventFormData,
          price: parseFloat(eventFormData.price)
        })
      });

      if (response.ok) {
        setIsEventModalOpen(false);
        fetchEvents();
      }
    } catch (err) {
      console.error('Failed to save event');
    }
  };

  const handleDeleteEvent = async (id: number) => {
    if (!confirm('Are you sure you want to delete this event?')) return;
    try {
      const response = await fetch(`/api/admin/events/${id}`, { method: 'DELETE' });
      if (response.ok) {
        fetchEvents();
      }
    } catch (err) {
      console.error('Failed to delete event');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const url = editingProduct ? `/api/admin/products/${editingProduct.id}` : '/api/admin/products';
    const method = editingProduct ? 'PUT' : 'POST';

    try {
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          price: parseFloat(formData.price),
          stock_quantity: parseInt(formData.stock_quantity)
        })
      });

      if (response.ok) {
        setIsModalOpen(false);
        fetchProducts();
      }
    } catch (err) {
      console.error('Failed to save product');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this product?')) return;

    try {
      const response = await fetch(`/api/admin/products/${id}`, { method: 'DELETE' });
      if (response.ok) {
        fetchProducts();
      }
    } catch (err) {
      console.error('Failed to delete product');
    }
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const lowStockCount = products.filter(p => p.stock_quantity < 10).length;
  const totalStock = products.reduce((acc, p) => acc + p.stock_quantity, 0);

  return (
    <div className="min-h-screen pb-32">
      {/* Admin Header */}
      <section className="px-6 pt-12 pb-8 border-b border-white/5 bg-zinc-900/50 backdrop-blur-xl">
        <div className="flex justify-between items-center mb-8">
          <div>
            <span className="text-brand-yellow text-xs font-black tracking-widest uppercase">Administration</span>
            <h1 className="text-4xl font-black italic uppercase tracking-tighter">Dashboard</h1>
          </div>
          {activeTab === 'gallery' ? (
            <button 
              onClick={() => handleOpenGalleryModal()}
              className="flex items-center gap-2 px-6 py-3 bg-brand-yellow text-black rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-105 transition-all"
            >
              <Plus size={18} /> Add to Gallery
            </button>
          ) : activeTab === 'events' ? (
            <button 
              onClick={() => handleOpenEventModal()}
              className="flex items-center gap-2 px-6 py-3 bg-brand-yellow text-black rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-105 transition-all"
            >
              <Plus size={18} /> Add Event
            </button>
          ) : (
            <button 
              onClick={() => handleOpenModal()}
              className="flex items-center gap-2 px-6 py-3 bg-brand-yellow text-black rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-105 transition-all"
            >
              <Plus size={18} /> Add Product
            </button>
          )}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-6 bg-zinc-900 border border-white/5 rounded-3xl">
            <div className="flex items-center gap-4 mb-2">
              <div className="w-10 h-10 bg-brand-yellow/10 rounded-xl flex items-center justify-center text-brand-yellow">
                <Package size={20} />
              </div>
              <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Total Products</span>
            </div>
            <p className="text-3xl font-black italic">{products.length}</p>
          </div>
          
          <div className="p-6 bg-zinc-900 border border-white/5 rounded-3xl">
            <div className="flex items-center gap-4 mb-2">
              <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500">
                <TrendingUp size={20} />
              </div>
              <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Total Inventory</span>
            </div>
            <p className="text-3xl font-black italic">{totalStock}</p>
          </div>

          <div className="p-6 bg-zinc-900 border border-white/5 rounded-3xl">
            <div className="flex items-center gap-4 mb-2">
              <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center text-red-500">
                <AlertTriangle size={20} />
              </div>
              <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Low Stock Alert</span>
            </div>
            <p className="text-3xl font-black italic text-red-500">{lowStockCount}</p>
          </div>
        </div>
      </section>

      {/* Tabs & Search */}
      <div className="px-6 py-8">
        <div className="flex flex-col md:flex-row gap-6 justify-between items-center mb-8">
          <div className="flex p-1 bg-zinc-900 rounded-2xl border border-white/5 w-full md:w-auto">
            <button
              onClick={() => setActiveTab('products')}
              className={`flex-1 md:flex-none px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === 'products' ? 'bg-brand-yellow text-black' : 'text-gray-500 hover:text-white'
              }`}
            >
              Products
            </button>
            <button
              onClick={() => setActiveTab('inventory')}
              className={`flex-1 md:flex-none px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === 'inventory' ? 'bg-brand-yellow text-black' : 'text-gray-500 hover:text-white'
              }`}
            >
              Inventory
            </button>
            <button
              onClick={() => setActiveTab('gallery')}
              className={`flex-1 md:flex-none px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === 'gallery' ? 'bg-brand-yellow text-black' : 'text-gray-500 hover:text-white'
              }`}
            >
              Gallery
            </button>
            <button
              onClick={() => setActiveTab('events')}
              className={`flex-1 md:flex-none px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === 'events' ? 'bg-brand-yellow text-black' : 'text-gray-500 hover:text-white'
              }`}
            >
              Events
            </button>
          </div>

          <div className="relative w-full md:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
            <input 
              type="text"
              placeholder="SEARCH PRODUCTS OR CATEGORIES..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-6 py-4 bg-zinc-900 border border-white/5 rounded-2xl text-[10px] font-bold uppercase tracking-widest focus:border-brand-yellow/50 outline-none transition-all"
            />
          </div>
        </div>

        {/* Content Table */}
        {activeTab === 'gallery' ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {gallery.map((item) => (
              <div key={item.id} className="group relative aspect-square bg-zinc-900 border border-white/5 rounded-2xl overflow-hidden">
                <img src={item.image_url} alt={item.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button 
                    onClick={() => handleOpenGalleryModal(item)}
                    className="p-3 bg-white/10 text-white rounded-xl hover:scale-110 transition-all"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button 
                    onClick={() => handleDeleteGallery(item.id)}
                    className="p-3 bg-red-500 text-white rounded-xl hover:scale-110 transition-all"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                {item.title && (
                  <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black to-transparent">
                    <p className="text-[10px] font-black uppercase tracking-widest truncate">{item.title}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : activeTab === 'events' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((event) => (
              <div key={event.id} className="group bg-zinc-900 border border-white/5 rounded-[32px] overflow-hidden">
                <div className="relative aspect-[4/5]">
                  <img src={event.image_url} alt={event.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <button 
                      onClick={() => handleOpenEventModal(event)}
                      className="p-4 bg-white/10 text-white rounded-2xl hover:scale-110 transition-all"
                    >
                      <Edit2 size={20} />
                    </button>
                    <button 
                      onClick={() => handleDeleteEvent(event.id)}
                      className="p-4 bg-red-500 text-white rounded-2xl hover:scale-110 transition-all"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-black italic uppercase tracking-tighter mb-2">{event.title}</h3>
                  <div className="flex flex-col gap-1">
                    <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                      <Calendar size={12} className="text-brand-yellow" /> {event.date}
                    </p>
                    <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                      {event.location}
                    </p>
                    <p className="text-lg font-black italic mt-2 text-brand-yellow">
                      {event.price === 0 ? 'FREE' : `${event.price.toLocaleString()} TZS`}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-zinc-900 border border-white/5 rounded-[32px] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-white/5 bg-white/5">
                    <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-gray-500">Product</th>
                    <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-gray-500">Category</th>
                    <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-gray-500">Price</th>
                    <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-gray-500">Stock</th>
                    <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-gray-500 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredProducts.map((product) => (
                    <tr key={product.id} className="hover:bg-white/[0.02] transition-colors group">
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-xl overflow-hidden bg-zinc-800 border border-white/10">
                            <img src={product.image_url} alt="" className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <p className="text-sm font-black italic uppercase tracking-tight">{product.name}</p>
                            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest truncate max-w-[200px]">
                              {product.description}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <span className="px-3 py-1 bg-white/5 rounded-lg text-[10px] font-black uppercase tracking-widest text-gray-400">
                          {product.category}
                        </span>
                      </td>
                      <td className="px-8 py-6 font-mono text-sm">
                        {product.price.toLocaleString()} TZS
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full ${
                            product.stock_quantity < 10 ? 'bg-red-500 animate-pulse' : 'bg-green-500'
                          }`} />
                          {activeTab === 'inventory' ? (
                            <div className="flex items-center bg-black/40 rounded-xl border border-white/10 overflow-hidden">
                              <button 
                                onClick={() => handleUpdateStock(product.id, product.stock_quantity - 1)}
                                className="px-3 py-1 hover:bg-white/10 text-gray-400 transition-colors"
                              >
                                -
                              </button>
                              <span className="px-3 py-1 text-sm font-black italic min-w-[40px] text-center">
                                {product.stock_quantity}
                              </span>
                              <button 
                                onClick={() => handleUpdateStock(product.id, product.stock_quantity + 1)}
                                className="px-3 py-1 hover:bg-white/10 text-gray-400 transition-colors"
                              >
                                +
                              </button>
                            </div>
                          ) : (
                            <span className={`text-sm font-black italic ${
                              product.stock_quantity < 10 ? 'text-red-500' : 'text-white'
                            }`}>
                              {product.stock_quantity}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => handleOpenModal(product)}
                            className="p-2 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-all"
                          >
                            <Edit2 size={16} />
                          </button>
                          <button 
                            onClick={() => handleDelete(product.id)}
                            className="p-2 hover:bg-red-500/10 rounded-lg text-gray-400 hover:text-red-500 transition-all"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

            {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setIsModalOpen(false)}
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="relative w-full max-w-2xl max-h-[90vh] bg-zinc-900 border border-white/10 rounded-[40px] shadow-2xl overflow-hidden flex flex-col"
          >
            <div className="p-8 border-b border-white/5 flex justify-between items-center flex-shrink-0">
              <div>
                <h2 className="text-2xl font-black italic uppercase tracking-tight">
                  {editingProduct ? 'Edit Product' : 'Add New Product'}
                </h2>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">
                  Fill in the details below
                </p>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-3 hover:bg-white/5 rounded-2xl text-gray-500 hover:text-white transition-all"
              >
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-8 space-y-6 overflow-y-auto no-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Product Name</label>
                  <input 
                    required
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                    placeholder="e.g. AFB Signature Tee"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Category</label>
                  <select 
                    value={formData.category}
                    onChange={(e) => setFormData({...formData, category: e.target.value})}
                    className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all appearance-none"
                  >
                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Price (TZS)</label>
                  <input 
                    required
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({...formData, price: e.target.value})}
                    className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Initial Stock</label>
                  <input 
                    required
                    type="number"
                    value={formData.stock_quantity}
                    onChange={(e) => setFormData({...formData, stock_quantity: e.target.value})}
                    className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                    placeholder="0"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Image URL or Upload</label>
                <div className="relative">
                  <Upload className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                  <input 
                    required
                    type="text"
                    value={formData.image_url}
                    onChange={(e) => setFormData({...formData, image_url: e.target.value})}
                    className="w-full pl-16 pr-32 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                    placeholder="https://example.com/image.jpg"
                  />
                  <label className="absolute right-4 top-1/2 -translate-y-1/2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer transition-all">
                    Browse
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={handleImageUpload}
                    />
                  </label>
                </div>
                {formData.image_url && (
                  <div className="mt-4 w-32 h-32 rounded-2xl overflow-hidden border border-white/10 bg-black/50">
                    <img src={formData.image_url} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Description</label>
                <textarea 
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all min-h-[120px] resize-none"
                  placeholder="Tell us about this product..."
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-4 bg-zinc-800 border border-white/5 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-zinc-700 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-4 bg-brand-yellow text-black rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                >
                  <Save size={18} /> {editingProduct ? 'Save Changes' : 'Create Product'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
      {/* Gallery Modal */}
      {isGalleryModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setIsGalleryModalOpen(false)}
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="relative w-full max-w-lg max-h-[90vh] bg-zinc-900 border border-white/10 rounded-[40px] shadow-2xl overflow-hidden flex flex-col"
          >
            <div className="p-8 border-b border-white/5 flex justify-between items-center flex-shrink-0">
              <div>
                <h2 className="text-2xl font-black italic uppercase tracking-tight">
                  {editingGalleryItem ? 'Edit Gallery Item' : 'Add to Gallery'}
                </h2>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">
                  {editingGalleryItem ? 'Update the details below' : 'Upload a new image'}
                </p>
              </div>
              <button 
                onClick={() => setIsGalleryModalOpen(false)}
                className="p-3 hover:bg-white/5 rounded-2xl text-gray-500 hover:text-white transition-all"
              >
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleGallerySubmit} className="p-8 space-y-6 overflow-y-auto no-scrollbar">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Image Title (Optional)</label>
                <input 
                  type="text"
                  value={galleryFormData.title}
                  onChange={(e) => setGalleryFormData({...galleryFormData, title: e.target.value})}
                  className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                  placeholder="e.g. AFB Pop-up Shop 2024"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Image URL or Upload</label>
                <div className="relative">
                  <Upload className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                  <input 
                    required
                    type="text"
                    value={galleryFormData.image_url}
                    onChange={(e) => setGalleryFormData({...galleryFormData, image_url: e.target.value})}
                    className="w-full pl-16 pr-32 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                    placeholder="https://example.com/image.jpg"
                  />
                  <label className="absolute right-4 top-1/2 -translate-y-1/2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer transition-all">
                    Browse
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={handleGalleryImageUpload}
                    />
                  </label>
                </div>
                {galleryFormData.image_url && (
                  <div className="mt-4 w-full aspect-video rounded-2xl overflow-hidden border border-white/10 bg-black/50">
                    <img src={galleryFormData.image_url} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  type="button"
                  onClick={() => setIsGalleryModalOpen(false)}
                  className="flex-1 py-4 bg-zinc-800 border border-white/5 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-zinc-700 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-4 bg-brand-yellow text-black rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                >
                  <Save size={18} /> {editingGalleryItem ? 'Save Changes' : 'Add to Gallery'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
      {/* Event Modal */}
      {isEventModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setIsEventModalOpen(false)}
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="relative w-full max-w-2xl max-h-[90vh] bg-zinc-900 border border-white/10 rounded-[40px] shadow-2xl overflow-hidden flex flex-col"
          >
            <div className="p-8 border-b border-white/5 flex justify-between items-center flex-shrink-0">
              <div>
                <h2 className="text-2xl font-black italic uppercase tracking-tight">
                  {editingEvent ? 'Edit Event' : 'Add New Event'}
                </h2>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">
                  Fill in the event details
                </p>
              </div>
              <button 
                onClick={() => setIsEventModalOpen(false)}
                className="p-3 hover:bg-white/5 rounded-2xl text-gray-500 hover:text-white transition-all"
              >
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleEventSubmit} className="p-8 space-y-6 overflow-y-auto no-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Event Title</label>
                  <input 
                    required
                    type="text"
                    value={eventFormData.title}
                    onChange={(e) => setEventFormData({...eventFormData, title: e.target.value})}
                    className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                    placeholder="e.g. King of Hearts Tour"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Date</label>
                  <input 
                    required
                    type="date"
                    value={eventFormData.date}
                    onChange={(e) => setEventFormData({...eventFormData, date: e.target.value})}
                    className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Location</label>
                  <input 
                    required
                    type="text"
                    value={eventFormData.location}
                    onChange={(e) => setEventFormData({...eventFormData, location: e.target.value})}
                    className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                    placeholder="e.g. Mlimani City, Dar"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Ticket Price (TZS)</label>
                  <input 
                    required
                    type="number"
                    value={eventFormData.price}
                    onChange={(e) => setEventFormData({...eventFormData, price: e.target.value})}
                    className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                    placeholder="0 for FREE"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 ml-2">Image URL or Upload</label>
                <div className="relative">
                  <Upload className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                  <input 
                    required
                    type="text"
                    value={eventFormData.image_url}
                    onChange={(e) => setEventFormData({...eventFormData, image_url: e.target.value})}
                    className="w-full pl-16 pr-32 py-4 bg-black/50 border border-white/10 rounded-2xl text-sm font-bold focus:border-brand-yellow outline-none transition-all"
                    placeholder="https://example.com/poster.jpg"
                  />
                  <label className="absolute right-4 top-1/2 -translate-y-1/2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer transition-all">
                    Browse
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={handleEventImageUpload}
                    />
                  </label>
                </div>
                {eventFormData.image_url && (
                  <div className="mt-4 w-32 h-40 rounded-2xl overflow-hidden border border-white/10 bg-black/50">
                    <img src={eventFormData.image_url} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  type="button"
                  onClick={() => setIsEventModalOpen(false)}
                  className="flex-1 py-4 bg-zinc-800 border border-white/5 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-zinc-700 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-4 bg-brand-yellow text-black rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                >
                  <Save size={18} /> {editingEvent ? 'Save Changes' : 'Create Event'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}
