import { useState, useEffect } from 'react';
import { AppEvent } from '../types';
import EventCard from '../components/EventCard';

export default function Events() {
  const [events, setEvents] = useState<AppEvent[]>([]);

  useEffect(() => {
    fetch('/api/events')
      .then(res => res.json())
      .then(data => setEvents(data));
  }, []);

  return (
    <div className="pb-24 pt-20 px-6">
      <div className="mb-12">
        <span className="text-brand-yellow text-xs font-bold tracking-widest uppercase">Live on Stage</span>
        <h1 className="text-5xl font-black tracking-tighter italic leading-none">CATCH <br />JUX LIVE</h1>
      </div>

      <div className="space-y-6">
        {events.map(event => (
          <EventCard key={event.id} event={event} />
        ))}
      </div>
    </div>
  );
}
