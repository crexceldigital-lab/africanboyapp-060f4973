import { useState, useEffect } from 'react';
import { Product } from '../types';
import ProductCard from '../components/ProductCard';
import { Filter, SlidersHorizontal } from 'lucide-react';

export default function Shop() {
  const [products, setProducts] = useState<Product[]>([]);
  const [category, setCategory] = useState('All');

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);

  const categories = ['All', 'Jeans', 'T-Shirt', 'Hoods', 'Caps', 'Phone Case', 'Footwear'];

  const filteredProducts = category === 'All' 
    ? products 
    : products.filter(p => p.category === category);

  return (
    <div className="pb-24 pt-20 px-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-black tracking-tighter italic">SHOP <span className="text-brand-yellow">AFB</span></h1>
        <div className="flex gap-2">
          <button className="p-2 bg-zinc-900 rounded-lg border border-white/5"><Filter size={20} /></button>
          <button className="p-2 bg-zinc-900 rounded-lg border border-white/5"><SlidersHorizontal size={20} /></button>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar mb-8">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`px-6 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all border ${
              category === cat 
                ? 'bg-brand-yellow text-black border-brand-yellow' 
                : 'bg-zinc-900 text-gray-400 border-white/5 hover:border-white/20'
            }`}
          >
            {cat.toUpperCase()}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredProducts.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
