import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Crown, Check, Zap, Plus, ArrowRight, ShoppingBag } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { useCountry } from '../context/CountryContext';

export default function VIP() {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedTop, setSelectedTop] = useState<Product | null>(null);
  const [selectedBottom, setSelectedBottom] = useState<Product | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [isAdded, setIsAdded] = useState(false);
  const { addToCart } = useCart();
  const { selectedCountry } = useCountry();

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);

  const tops = products.filter(p => ['T-Shirt', 'Hoods'].includes(p.category));
  const bottoms = products.filter(p => p.category === 'Jeans');

  const comboPrice = selectedTop && selectedBottom 
    ? (selectedTop.price + selectedBottom.price) * 0.85 // 15% discount
    : 0;

  const handleAddComboToCart = () => {
    if (selectedTop && selectedBottom) {
      const comboItem: Product = {
        id: Math.random(), 
        name: `COMBO: ${selectedTop.name} + ${selectedBottom.name}`,
        price: comboPrice,
        category: 'Combo',
        image_url: selectedTop.image_url,
        description: `Exclusive Combo Kit including ${selectedTop.name} and ${selectedBottom.name}.`,
        stock_quantity: 1
      };
      
      addToCart(comboItem);
      setIsAdded(true);
      setTimeout(() => {
        setIsAdded(false);
        setSelectedTop(null);
        setSelectedBottom(null);
        setCurrentStep(1);
      }, 2000);
    }
  };

  return (
    <div className="pb-24 pt-20 px-6 max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="inline-block p-4 bg-brand-yellow/10 rounded-full mb-4"
        >
          <Zap size={48} className="text-brand-yellow" />
        </motion.div>
        <h1 className="text-4xl font-black tracking-tighter italic uppercase">Exclusive <span className="text-brand-yellow">Combo Kits</span></h1>
        <p className="text-gray-500 text-sm mt-2">The ultimate style pairing. Build your look and save.</p>
      </div>

      {/* Combo Kit Section */}
      <section className="pt-4">
        <div className="text-center mb-12">
          <div className="inline-block px-4 py-1 bg-brand-yellow/10 border border-brand-yellow/20 rounded-full mb-4">
            <span className="text-[10px] font-black text-brand-yellow uppercase tracking-widest">Exclusive Deal</span>
          </div>
          <h2 className="text-2xl font-black tracking-tighter italic uppercase">Build Your <span className="text-brand-yellow">Custom Bundle</span></h2>
          <p className="text-gray-500 text-sm mt-2">Combine any Top & Bottom for an automatic 15% discount.</p>
          
          {/* Step Indicator */}
          <div className="flex justify-center items-center gap-4 mt-8">
            <div className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all ${currentStep === 1 ? 'bg-brand-yellow border-brand-yellow text-black' : 'bg-zinc-900 border-white/10 text-gray-500'}`}>
              <span className="text-xs font-black">01</span>
              <span className="text-[10px] font-bold uppercase tracking-widest">Select Top</span>
            </div>
            <div className="w-8 h-[1px] bg-white/10" />
            <div className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all ${currentStep === 2 ? 'bg-brand-yellow border-brand-yellow text-black' : 'bg-zinc-900 border-white/10 text-gray-500'}`}>
              <span className="text-xs font-black">02</span>
              <span className="text-[10px] font-bold uppercase tracking-widest">Select Bottom</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {currentStep === 1 ? (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-6"
                >
                  <div className="flex justify-between items-center">
                    <h3 className="text-xs font-black uppercase tracking-widest text-gray-500 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-brand-yellow" /> Step 1: Choose your Top
                    </h3>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {tops.map(product => (
                      <button
                        key={product.id}
                        onClick={() => {
                          setSelectedTop(product);
                          setCurrentStep(2);
                        }}
                        className={`group relative aspect-[3/4] rounded-3xl overflow-hidden border-2 transition-all ${
                          selectedTop?.id === product.id ? 'border-brand-yellow scale-[0.98]' : 'border-white/5 hover:border-white/20'
                        }`}
                      >
                        <img src={product.image_url} alt={product.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-4">
                          <p className="text-[10px] font-black uppercase tracking-tighter text-brand-yellow mb-1">{product.category}</p>
                          <p className="text-xs font-bold truncate">{product.name}</p>
                        </div>
                        {selectedTop?.id === product.id && (
                          <div className="absolute top-3 right-3 w-6 h-6 bg-brand-yellow rounded-full flex items-center justify-center text-black">
                            <Check size={14} strokeWidth={3} />
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="flex justify-between items-center">
                    <h3 className="text-xs font-black uppercase tracking-widest text-gray-500 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-brand-yellow" /> Step 2: Choose your Bottom
                    </h3>
                    <button 
                      onClick={() => setCurrentStep(1)}
                      className="text-[10px] font-black uppercase tracking-widest text-brand-yellow hover:underline"
                    >
                      ← Back to Tops
                    </button>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {bottoms.map(product => (
                      <button
                        key={product.id}
                        onClick={() => setSelectedBottom(product)}
                        className={`group relative aspect-[3/4] rounded-3xl overflow-hidden border-2 transition-all ${
                          selectedBottom?.id === product.id ? 'border-brand-yellow scale-[0.98]' : 'border-white/5 hover:border-white/20'
                        }`}
                      >
                        <img src={product.image_url} alt={product.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-4">
                          <p className="text-[10px] font-black uppercase tracking-tighter text-brand-yellow mb-1">{product.category}</p>
                          <p className="text-xs font-bold truncate">{product.name}</p>
                        </div>
                        {selectedBottom?.id === product.id && (
                          <div className="absolute top-3 right-3 w-6 h-6 bg-brand-yellow rounded-full flex items-center justify-center text-black">
                            <Check size={14} strokeWidth={3} />
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Combo Summary */}
          <div className="lg:pl-4">
            <motion.div 
              layout
              className="bg-zinc-900 border border-white/5 rounded-[32px] p-8 sticky top-24 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-black italic uppercase tracking-tighter">Combo Summary</h3>
                {selectedTop && selectedBottom && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="px-2 py-1 bg-green-500/20 border border-green-500/30 rounded-md"
                  >
                    <span className="text-[8px] font-black text-green-500 uppercase tracking-widest">Bundle Active</span>
                  </motion.div>
                )}
              </div>
              
              <div className="space-y-4 mb-8">
                <AnimatePresence mode="popLayout">
                  <motion.div 
                    key={selectedTop?.id || 'empty-top'}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center justify-between p-4 bg-black/40 rounded-2xl border border-white/5"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-zinc-800 border border-white/5">
                        {selectedTop ? <img src={selectedTop.image_url} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-gray-600"><ShoppingBag size={16} /></div>}
                      </div>
                      <div>
                        <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Top</p>
                        <p className="text-xs font-bold truncate max-w-[120px]">{selectedTop?.name || 'Not selected'}</p>
                      </div>
                    </div>
                    {selectedTop && <Check size={16} className="text-brand-yellow" />}
                  </motion.div>

                  <motion.div className="flex items-center justify-center">
                    <Plus size={16} className="text-gray-700" />
                  </motion.div>

                  <motion.div 
                    key={selectedBottom?.id || 'empty-bottom'}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center justify-between p-4 bg-black/40 rounded-2xl border border-white/5"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-zinc-800 border border-white/5">
                        {selectedBottom ? <img src={selectedBottom.image_url} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-gray-600"><ShoppingBag size={16} /></div>}
                      </div>
                      <div>
                        <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Bottom</p>
                        <p className="text-xs font-bold truncate max-w-[120px]">{selectedBottom?.name || 'Not selected'}</p>
                      </div>
                    </div>
                    {selectedBottom && <Check size={16} className="text-brand-yellow" />}
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="pt-6 border-t border-white/5 space-y-2 mb-8">
                <div className="flex justify-between text-xs font-bold text-gray-500 uppercase tracking-widest">
                  <span>Regular Total</span>
                  <span className="line-through">{( (selectedTop?.price || 0) + (selectedBottom?.price || 0) ).toLocaleString()} TZS</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs font-black uppercase tracking-widest text-brand-yellow">Combo Price</span>
                  <motion.span 
                    key={comboPrice}
                    initial={{ scale: 1.2, color: '#F27D26' }}
                    animate={{ scale: 1, color: '#FFFFFF' }}
                    className="text-2xl font-black italic"
                  >
                    {comboPrice.toLocaleString()} TZS
                  </motion.span>
                </div>
                <p className="text-[9px] font-bold text-green-500 uppercase tracking-widest text-right">You save 15%</p>
              </div>

              <button
                disabled={!selectedTop || !selectedBottom || isAdded}
                onClick={handleAddComboToCart}
                className={`w-full py-4 rounded-2xl font-black text-xs tracking-widest uppercase transition-all flex items-center justify-center gap-2 ${
                  isAdded 
                    ? 'bg-green-500 text-white'
                    : selectedTop && selectedBottom 
                      ? 'bg-brand-yellow text-black hover:scale-[1.02] active:scale-[0.98]' 
                      : 'bg-white/5 text-gray-600 cursor-not-allowed'
                }`}
              >
                {isAdded ? (
                  <>Added to Cart <Check size={16} /></>
                ) : (
                  <>Add Combo to Cart <ArrowRight size={16} /></>
                )}
              </button>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
