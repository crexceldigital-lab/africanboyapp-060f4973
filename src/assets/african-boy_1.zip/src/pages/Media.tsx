import { useState, useEffect } from 'react';
import { ContentItem, GalleryItem } from '../types';
import MediaCard from '../components/MediaCard';
import { Play, Image as ImageIcon } from 'lucide-react';

export default function Media() {
  const [content, setContent] = useState<ContentItem[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);

  useEffect(() => {
    fetch('/api/content')
      .then(res => res.json())
      .then(data => setContent(data));
    
    fetch('/api/gallery')
      .then(res => res.json())
      .then(data => setGallery(data));
  }, []);

  return (
    <div className="pb-24 pt-20 px-6 space-y-12">
      <section>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-black tracking-tighter italic uppercase">Exclusive <span className="text-brand-yellow">Videos</span></h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {content.map(item => (
            <MediaCard key={item.id} item={item} />
          ))}
        </div>
      </section>

      <section>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-black tracking-tighter italic uppercase">Photo <span className="text-brand-yellow">Gallery</span></h1>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {gallery.map(item => (
            <div key={item.id} className="group relative aspect-square bg-zinc-900 border border-white/5 rounded-2xl overflow-hidden">
              <img src={item.image_url} alt={item.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
              {item.title && (
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <p className="text-xs font-black uppercase tracking-widest">{item.title}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
