import { useState } from 'react';
import { NavTab } from './types';
import Navbar from './components/Navbar';
import Header from './components/Header';
import Home from './pages/Home';
import Shop from './pages/Shop';
import Events from './pages/Events';
import Media from './pages/Media';
import VIP from './pages/VIP';
import Profile from './pages/Profile';
import Admin from './pages/Admin';
import Login from './pages/Login';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';
import { CartProvider } from './context/CartContext';
import { useCountry } from './context/CountryContext';

export default function App() {
  const { user, loading, error } = useCountry();
  const [activeTab, setActiveTab] = useState<NavTab>('home');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-2 border-brand-yellow border-t-transparent animate-spin" />
          <p className="text-brand-yellow font-bold text-[10px] tracking-widest uppercase">Initializing Movement...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black px-6">
        <div className="text-center space-y-6 max-w-xs">
          <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto text-red-500 border border-red-500/20">
            <X size={32} />
          </div>
          <div className="space-y-2">
            <h2 className="text-xl font-black italic uppercase tracking-tight">Startup Error</h2>
            <p className="text-gray-500 text-xs font-bold uppercase tracking-widest leading-relaxed">{error}</p>
          </div>
          <button 
            onClick={() => window.location.reload()}
            className="w-full py-4 bg-zinc-900 border border-white/10 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-zinc-800 transition-all"
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const renderPage = () => {
    switch (activeTab) {
      case 'home':
        return <Home onNavigate={setActiveTab} />;
      case 'shop':
        return <Shop />;
      case 'video':
        return <Media />;
      case 'events':
        return <Events />;
      case 'vip':
        return <VIP />;
      case 'profile':
        return <Profile />;
      case 'admin':
        return <Admin />;
      default:
        return <Home onNavigate={setActiveTab} />;
    }
  };

  return (
    <CartProvider>
      <div className="min-h-screen bg-brand-black text-white selection:bg-brand-yellow selection:text-black">
        <Header />
        
        <main className="max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderPage()}
            </motion.div>
          </AnimatePresence>
        </main>

        <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>
    </CartProvider>
  );
}
