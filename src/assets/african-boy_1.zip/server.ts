import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";

const db = new Database("african_boy.db");

// Initialize Database Schema
db.exec(`
  CREATE TABLE IF NOT EXISTS countries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE,
    code TEXT UNIQUE,
    flag_emoji TEXT,
    currency_code TEXT,
    currency_symbol TEXT,
    is_active BOOLEAN DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS exchange_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_currency TEXT,
    to_currency TEXT,
    rate REAL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(from_currency, to_currency)
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    phone_number TEXT UNIQUE,
    password TEXT,
    full_name TEXT,
    role TEXT DEFAULT 'fan',
    vip_tier TEXT DEFAULT 'none',
    country_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(country_id) REFERENCES countries(id)
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    price REAL,
    category TEXT,
    image_url TEXT,
    description TEXT,
    stock_quantity INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    date TEXT,
    location TEXT,
    price REAL,
    image_url TEXT
  );

  CREATE TABLE IF NOT EXISTS content (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    type TEXT, -- 'audio', 'video', 'news'
    url TEXT,
    is_vip BOOLEAN DEFAULT 0,
    thumbnail_url TEXT
  );

  CREATE TABLE IF NOT EXISTS purchases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    product_name TEXT,
    amount REAL,
    currency_code TEXT DEFAULT 'TZS',
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS gallery (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    image_url TEXT,
    title TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Migration: Add phone_number and password to users if they don't exist
const tableInfo = db.prepare("PRAGMA table_info(users)").all() as any[];
const hasPhoneNumber = tableInfo.some(col => col.name === 'phone_number');
const hasPassword = tableInfo.some(col => col.name === 'password');

if (!hasPhoneNumber) {
  db.exec("ALTER TABLE users ADD COLUMN phone_number TEXT");
  db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_phone_number ON users(phone_number)");
}
if (!hasPassword) {
  db.exec("ALTER TABLE users ADD COLUMN password TEXT");
}

// Seed countries if empty
const countryCount = db.prepare("SELECT COUNT(*) as count FROM countries").get() as { count: number };
if (countryCount.count === 0) {
  const insertCountry = db.prepare("INSERT INTO countries (name, code, flag_emoji, currency_code, currency_symbol) VALUES (?, ?, ?, ?, ?)");
  insertCountry.run("Tanzania", "TZ", "🇹🇿", "TZS", "TZS");
  insertCountry.run("Nigeria", "NG", "🇳🇬", "NGN", "₦");
  
  const insertRate = db.prepare("INSERT INTO exchange_rates (from_currency, to_currency, rate) VALUES (?, ?, ?)");
  insertRate.run("TZS", "NGN", 0.56);
}

// Ensure the specific email is the only admin
const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as { count: number };
if (userCount.count === 0) {
  // Seed the admin user
  const insertUser = db.prepare("INSERT INTO users (email, phone_number, password, full_name, role, vip_tier, country_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
  insertUser.run("mwingiranorbert@gmail.com", "+255712345678", "admin123", "Norbert Mwingira", "admin", "Platinum", 1);
} else {
  db.prepare("UPDATE users SET role = 'fan' WHERE role = 'admin' AND email != 'mwingiranorbert@gmail.com'").run();
  
  // Check if our admin exists, if not create them
  const admin = db.prepare("SELECT * FROM users WHERE email = 'mwingiranorbert@gmail.com'").get();
  if (!admin) {
    const insertUser = db.prepare("INSERT INTO users (email, phone_number, password, full_name, role, vip_tier, country_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    insertUser.run("mwingiranorbert@gmail.com", "+255712345678", "admin123", "Norbert Mwingira", "admin", "Platinum", 1);
  } else {
    // Ensure they have the admin role
    db.prepare("UPDATE users SET role = 'admin' WHERE email = 'mwingiranorbert@gmail.com'").run();
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // API Routes
  app.get("/api/countries", (req, res) => {
    const countries = db.prepare("SELECT * FROM countries WHERE is_active = 1").all();
    res.json(countries);
  });

  app.get("/api/exchange-rates", (req, res) => {
    const rates = db.prepare("SELECT * FROM exchange_rates").all();
    res.json(rates);
  });

  app.get("/api/products", (req, res) => {
    const products = db.prepare("SELECT * FROM products").all();
    res.json(products);
  });

  app.get("/api/events", (req, res) => {
    const events = db.prepare("SELECT * FROM events").all();
    res.json(events);
  });

  app.get("/api/content", (req, res) => {
    const content = db.prepare("SELECT * FROM content").all();
    res.json(content);
  });

  app.get("/api/gallery", (req, res) => {
    const gallery = db.prepare("SELECT * FROM gallery ORDER BY created_at DESC").all();
    res.json(gallery);
  });

  app.post("/api/login", (req, res) => {
    try {
      const { identifier, password } = req.body; // identifier can be email or phone
      const user = db.prepare(`
        SELECT users.*, countries.name as country_name, countries.code as country_code, 
               countries.currency_code, countries.currency_symbol
        FROM users 
        LEFT JOIN countries ON users.country_id = countries.id
        WHERE (email = ? OR phone_number = ?) AND password = ?
      `).get(identifier, identifier, password);

      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Enforce admin restriction: only mwingiranorbert@gmail.com can be admin
      if (user.role === 'admin' && user.email !== 'mwingiranorbert@gmail.com') {
        return res.status(403).json({ error: "Unauthorized administration access" });
      }

      res.json(user);
    } catch (err) {
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.post("/api/signup", (req, res) => {
    try {
      const { email, phone_number, password, full_name, country_id } = req.body;
      const result = db.prepare("INSERT INTO users (email, phone_number, password, full_name, country_id) VALUES (?, ?, ?, ?, ?)").run(email, phone_number, password, full_name, country_id || 1);
      const user = db.prepare(`
        SELECT users.*, countries.name as country_name, countries.code as country_code, 
               countries.currency_code, countries.currency_symbol
        FROM users 
        LEFT JOIN countries ON users.country_id = countries.id
        WHERE users.id = ?
      `).get(result.lastInsertRowid);
      res.json(user);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Signup failed. Email or phone might already exist." });
    }
  });

  app.get("/api/user", (req, res) => {
    try {
      const user = db.prepare(`
        SELECT users.*, countries.name as country_name, countries.code as country_code, 
               countries.currency_code, countries.currency_symbol
        FROM users 
        LEFT JOIN countries ON users.country_id = countries.id
        LIMIT 1
      `).get();
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (err) {
      res.status(500).json({ error: "Database error" });
    }
  });

  app.post("/api/user", (req, res) => {
    try {
      const { id, full_name, email, country_id } = req.body;
      if (country_id) {
        db.prepare("UPDATE users SET full_name = ?, email = ?, country_id = ? WHERE id = ?").run(full_name, email, country_id, id);
      } else {
        db.prepare("UPDATE users SET full_name = ?, email = ? WHERE id = ?").run(full_name, email, id);
      }
      const user = db.prepare(`
        SELECT users.*, countries.name as country_name, countries.code as country_code, 
               countries.currency_code, countries.currency_symbol
        FROM users 
        LEFT JOIN countries ON users.country_id = countries.id
        WHERE users.id = ?
      `).get(id);
      res.json(user);
    } catch (err) {
      res.status(500).json({ error: "Update failed" });
    }
  });

  app.get("/api/purchases", (req, res) => {
    try {
      const purchases = db.prepare("SELECT * FROM purchases ORDER BY date DESC").all();
      res.json(purchases || []);
    } catch (err) {
      res.status(500).json({ error: "Database error" });
    }
  });

  app.post("/api/checkout", (req, res) => {
    try {
      const { user_id, items, currency_code } = req.body;
      const insertPurchase = db.prepare("INSERT INTO purchases (user_id, product_name, amount, currency_code) VALUES (?, ?, ?, ?)");
      const updateStock = db.prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");
      
      const transaction = db.transaction((items) => {
        for (const item of items) {
          insertPurchase.run(user_id, item.name, item.price * item.quantity, currency_code || 'TZS');
          updateStock.run(item.quantity, item.id);
        }
      });

      transaction(items);
      res.json({ success: true });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Checkout failed" });
    }
  });

  // Admin Routes
  app.post("/api/admin/events", (req, res) => {
    try {
      const { title, date, location, price, image_url } = req.body;
      const result = db.prepare(`
        INSERT INTO events (title, date, location, price, image_url)
        VALUES (?, ?, ?, ?, ?)
      `).run(title, date, location, price, image_url);
      res.json({ id: result.lastInsertRowid });
    } catch (err) {
      res.status(500).json({ error: "Failed to create event" });
    }
  });

  app.put("/api/admin/events/:id", (req, res) => {
    try {
      const { id } = req.params;
      const { title, date, location, price, image_url } = req.body;
      db.prepare(`
        UPDATE events 
        SET title = ?, date = ?, location = ?, price = ?, image_url = ?
        WHERE id = ?
      `).run(title, date, location, price, image_url, id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to update event" });
    }
  });

  app.delete("/api/admin/events/:id", (req, res) => {
    try {
      const { id } = req.params;
      db.prepare("DELETE FROM events WHERE id = ?").run(id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete event" });
    }
  });

  app.post("/api/admin/products", (req, res) => {
    try {
      const { name, price, category, image_url, description, stock_quantity } = req.body;
      const result = db.prepare(`
        INSERT INTO products (name, price, category, image_url, description, stock_quantity)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(name, price, category, image_url, description, stock_quantity || 0);
      res.json({ id: result.lastInsertRowid });
    } catch (err) {
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  app.put("/api/admin/products/:id", (req, res) => {
    try {
      const { id } = req.params;
      const { name, price, category, image_url, description, stock_quantity } = req.body;
      db.prepare(`
        UPDATE products 
        SET name = ?, price = ?, category = ?, image_url = ?, description = ?, stock_quantity = ?
        WHERE id = ?
      `).run(name, price, category, image_url, description, stock_quantity, id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  app.delete("/api/admin/products/:id", (req, res) => {
    try {
      const { id } = req.params;
      db.prepare("DELETE FROM products WHERE id = ?").run(id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  app.get("/api/admin/inventory", (req, res) => {
    try {
      const inventory = db.prepare("SELECT id, name, category, stock_quantity, price FROM products").all();
      res.json(inventory);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch inventory" });
    }
  });

  app.post("/api/admin/gallery", (req, res) => {
    try {
      const { image_url, title } = req.body;
      const result = db.prepare("INSERT INTO gallery (image_url, title) VALUES (?, ?)").run(image_url, title || "");
      res.json({ id: result.lastInsertRowid });
    } catch (err) {
      res.status(500).json({ error: "Failed to add to gallery" });
    }
  });

  app.delete("/api/admin/gallery/:id", (req, res) => {
    try {
      const { id } = req.params;
      db.prepare("DELETE FROM gallery WHERE id = ?").run(id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete from gallery" });
    }
  });

  app.put("/api/admin/gallery/:id", (req, res) => {
    try {
      const { id } = req.params;
      const { image_url, title } = req.body;
      db.prepare("UPDATE gallery SET image_url = ?, title = ? WHERE id = ?").run(image_url, title, id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to update gallery item" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve(__dirname, "dist/index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
